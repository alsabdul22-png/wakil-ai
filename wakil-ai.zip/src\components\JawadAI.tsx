'use client';

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Bot, X, Send, User, MessageCircle, ShieldCheck, Zap, Command, Activity, Fingerprint } from 'lucide-react';
import { usePathname } from 'next/navigation';

export default function JawadAI() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<{ role: 'ai' | 'user'; content: string }[]>([
    { role: 'ai', content: "Greetings. I am JAWAD AI — your Strategic Intelligence Guide. How shall we navigate the node today?" }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  
  const pathname = usePathname();
  const getContext = () => {
    return {
      page: pathname || "home",
      feature: pathname === "/chat" ? "AI Chat Platform" : pathname === "/" ? "Landing Page" : "General Platform"
    };
  };

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isTyping, isOpen]);

  const handleSend = async () => {
    if (!input.trim() || isTyping) return;
    const userMsg = input.trim();
    setMessages(p => [...p, { role: 'user', content: userMsg }]);
    setInput('');
    setIsTyping(true);

    try {
      const res = await fetch('/api/jawad', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: messages.map(m => ({ role: m.role === 'ai' ? 'assistant' : 'user', content: m.content })).concat([{ role: 'user', content: userMsg }]),
          context: getContext()
        })
      });
      const data = await res.json();
      if (data.choices?.[0]?.message?.content) {
        setMessages(p => [...p, { role: 'ai', content: data.choices[0].message.content }]);
      } else {
        throw new Error("No response");
      }
    } catch (e: any) {
      setMessages(p => [...p, { role: 'ai', content: "Neural sync interrupted. Protocol failure." }]);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className="fixed bottom-12 right-12 z-[100] flex flex-col items-end pointer-events-none">
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 30, scale: 0.9, rotateX: 20 }}
            animate={{ opacity: 1, y: 0, scale: 1, rotateX: 0 }}
            exit={{ opacity: 0, y: 30, scale: 0.9, rotateX: 20 }}
            transition={{ type: "spring", damping: 20, stiffness: 200 }}
            className="mb-10 w-[calc(100vw-4rem)] sm:w-[500px] h-[75dvh] sm:h-[650px] glass rounded-[3.5rem] border border-white/10 shadow-[0_50px_150px_rgba(0,0,0,0.95)] flex flex-col overflow-hidden pointer-events-auto relative origin-bottom-right"
          >
            {/* Header */}
            <div className="bg-slate-900/40 p-6 flex items-center justify-between border-b border-white/5 relative overflow-hidden backdrop-blur-4xl shadow-xl">
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-emerald-500 to-transparent shadow-glow" />
              <div className="flex items-center gap-4 relative z-10">
                <div className="w-12 h-12 flex items-center justify-center p-1.5 rounded-xl glass-light border border-emerald-500/20 shadow-glow">
                  <img src="/jawad-logo.png" className="w-full h-full object-contain drop-shadow-[0_0_10px_#10b981]" alt="JAWAD AI" />
                </div>
                <div>
                  <h3 className="text-white font-black text-base uppercase tracking-[0.2em] italic leading-none">JAWAD AI</h3>
                  <div className="flex items-center gap-2 mt-1">
                    <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse shadow-glow" />
                    <p className="text-slate-500 text-[0.55rem] font-bold uppercase tracking-widest">Active</p>
                  </div>
                </div>
              </div>
              <button 
                onClick={() => setIsOpen(false)}
                className="w-10 h-10 rounded-xl glass-light flex items-center justify-center hover:bg-emerald-500 hover:text-black transition-all border border-white/5"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Chat Area */}
            <div className="flex-1 overflow-y-auto p-6 space-y-8 custom-scrollbar bg-black/40 relative">
              <div className="absolute inset-0 bg-mesh opacity-10 pointer-events-none" />
              
              {messages.map((m, i) => (
                <motion.div 
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  key={i} 
                  className={`flex gap-4 w-full ${m.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}
                >
                  <div className={cn(
                    "w-9 h-9 flex items-center justify-center shrink-0 rounded-lg relative shadow-md backdrop-blur-4xl border",
                    m.role === 'user' ? "glass-light border-white/10" : "glass border-emerald-500/20"
                  )}>
                    {m.role === 'user' ? <User className="w-5 h-5 text-slate-400" /> : <img src="/jawad-logo.png" className="w-8 h-8 object-contain mix-blend-screen drop-shadow-[0_0_8px_#10b981]" alt="AI" />}
                  </div>
                  <div 
                    className={cn(
                      "px-6 py-4 rounded-[1.5rem] max-w-[85%] text-sm font-medium leading-relaxed shadow-lg",
                      m.role === 'user' 
                        ? 'bg-emerald-600 text-black font-bold tracking-tight rounded-tr-sm italic' 
                        : 'glass-light text-slate-200 border border-white/5 rounded-tl-sm backdrop-blur-4xl'
                    )}
                  >
                    {m.content}
                  </div>
                </motion.div>
              ))}
              {isTyping && (
                <div className="flex gap-6 w-full">
                  <div className="w-12 h-12 glass border border-emerald-500/20 flex items-center justify-center rounded-[1.2rem] animate-pulse">
                    <img src="/jawad-logo.png" className="w-10 h-10 object-contain mix-blend-screen" alt="T" />
                  </div>
                  <div className="glass-light px-10 py-6 rounded-[2.5rem] rounded-tl-sm flex items-center gap-4 shadow-3xl">
                    <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-bounce" style={{ animationDelay: '0ms' }} />
                    <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-bounce" style={{ animationDelay: '200ms' }} />
                    <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-bounce" style={{ animationDelay: '400ms' }} />
                  </div>
                </div>
              )}
              <div ref={scrollRef} className="h-4" />
            </div>

            {/* Input */}
            <div className="p-6 bg-slate-900/60 border-t border-white/5 backdrop-blur-4xl shadow-inner">
              <div className="relative flex items-center bg-white/[0.03] rounded-2xl p-2 border border-white/10 focus-within:border-emerald-500/40 transition-all shadow-xl">
                <input 
                  type="text" 
                  value={input}
                  onChange={e => setInput(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && handleSend()}
                  placeholder="Ask Jawad..."
                  className="flex-1 bg-transparent outline-none px-6 py-4 text-sm text-white font-medium placeholder-slate-700 tracking-tight"
                />
                <button 
                  onClick={handleSend}
                  disabled={isTyping || !input.trim()}
                  className="w-14 h-14 rounded-3xl bg-emerald-500 flex items-center justify-center text-black disabled:opacity-20 hover:scale-[1.05] active:scale-95 transition-all shadow-glow"
                >
                  <Send className="w-7 h-7 ml-1" />
                </button>
              </div>
              <div className="mt-4 flex items-center justify-between px-4 opacity-30">
                 <div className="flex items-center gap-3">
                    <Fingerprint className="w-4 h-4 text-emerald-500" />
                    <span className="text-[0.6rem] font-black uppercase tracking-[0.4em] text-slate-500">Secure_Path</span>
                 </div>
                 <span className="text-[0.6rem] font-black uppercase tracking-[0.4em] text-slate-500 text-right">0x4F2A</span>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <motion.button
        whileHover={{ scale: 1.05, y: -5 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-6 glass px-10 py-5 rounded-full shadow-[0_40px_100px_rgba(16,185,129,0.4)] border border-emerald-500/40 group pointer-events-auto relative backdrop-blur-4xl group"
      >
        <div className="absolute -inset-1 bg-emerald-500/20 blur-xl opacity-0 group-hover:opacity-100 transition-opacity" />
        <div className="w-10 h-10 flex items-center justify-center relative">
          <motion.img 
            animate={{ rotate: 360 }}
            transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
            src="/jawad-logo.png" 
            className="w-[150%] h-[150%] object-contain drop-shadow-[0_0_15px_#10b981]" 
          />
        </div>
        <div className="text-left font-inter">
           <p className="text-[0.6rem] font-black uppercase tracking-[0.5em] text-emerald-500 leading-none mb-1.5 opacity-60">Strategic_Guide</p>
           <span className="text-white font-black text-base uppercase tracking-[0.3em] italic leading-none">Jawad AI</span>
        </div>
      </motion.button>
      
      <style jsx global>{`
        .shadow-glow { box-shadow: 0 0 50px rgba(16, 185, 129, 0.4); }
        .shadow-3xl { box-shadow: 0 40px 100px rgba(0, 0, 0, 0.8); }
        .backdrop-blur-4xl { backdrop-filter: blur(60px); -webkit-backdrop-filter: blur(60px); }
        .custom-scrollbar::-webkit-scrollbar { width: 5px; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: rgba(16, 185, 129, 0.2); border-radius: 10px; }
      `}</style>
    </div>
  );
}

function cn(...inputs: any[]) {
  return inputs.filter(Boolean).join(' ');
}
