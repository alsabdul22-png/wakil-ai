import { createClient } from "@libsql/client";

const url = process.env.DATABASE_URL || "file:wakil.db";
const authToken = process.env.DATABASE_AUTH_TOKEN;

const db = createClient({
  url: url,
  authToken: authToken,
});

// Initialize schema (optional, but good for local)
async function initDb() {
  await db.execute(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      name TEXT,
      email TEXT UNIQUE,
      password TEXT,
      image TEXT
    );
  `);
}

initDb().catch(console.error);

export default db;
