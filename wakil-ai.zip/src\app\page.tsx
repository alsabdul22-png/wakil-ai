'use client';

import React, { useRef, useState, useEffect } from 'react';
import { motion, useScroll, useTransform, AnimatePresence } from 'framer-motion';
import {
  Zap, Shield, Globe, Cpu, ArrowRight,
  ImageIcon, Terminal, Workflow, MousePointer2, 
  Layers, Rocket, Send, Search, MessageSquare,
  Activity, Fingerprint, Sparkles, Command
} from 'lucide-react';
import Link from 'next/link';

// --- COMPONENTS ---

const FeatureCard = ({ title, desc, icon: Icon, index }: any) => (
  <motion.div 
    initial={{ opacity: 0, y: 40 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true }}
    transition={{ delay: index * 0.1, duration: 0.8 }}
    whileHover={{ y: -15, scale: 1.05 }}
    className="glass p-10 rounded-[3.5rem] border-white/5 hover:border-[#10b981]/60 group transition-all relative overflow-hidden shadow-[0_30px_100px_rgba(0,0,0,0.6)]"
  >
    <div className="absolute -right-16 -top-16 w-48 h-48 bg-[#10b981]/5 blur-3xl group-hover:bg-[#10b981]/15 transition-all duration-700" />
    <div className="w-20 h-20 rounded-3xl bg-[#10b981]/10 flex items-center justify-center mb-10 border border-[#10b981]/30 group-hover:rotate-[15deg] group-hover:bg-emerald-500 group-hover:text-black transition-all shadow-[0_0_30px_rgba(16,185,129,0.2)]">
      <Icon className="w-10 h-10" />
    </div>
    <h3 className="text-3xl font-black text-white mb-6 uppercase italic tracking-tighter leading-none">{title}</h3>
    <p className="text-slate-400 text-base leading-relaxed font-medium group-hover:text-slate-200 transition-colors">{desc}</p>
    <div className="mt-8 flex items-center gap-3 text-emerald-500 font-black text-[0.6rem] uppercase tracking-[0.4em] opacity-0 group-hover:opacity-100 transition-opacity">
      Establish Link <ArrowRight className="w-4 h-4" />
    </div>
  </motion.div>
);

const NewsCard = ({ date, title, desc, tag, index }: any) => (
  <motion.div 
    initial={{ opacity: 0, x: -30 }}
    whileInView={{ opacity: 1, x: 0 }}
    viewport={{ once: true }}
    transition={{ delay: index * 0.15, duration: 0.8 }}
    className="glass p-10 rounded-[3.5rem] border-l-[6px] border-l-emerald-500 border-white/5 hover:bg-emerald-500/[0.07] transition-all group cursor-pointer relative overflow-hidden shadow-[0_40px_120px_rgba(0,0,0,0.7)]"
  >
    <div className="flex justify-between items-center mb-8">
      <div className="flex items-center gap-4">
        <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
        <span className="text-[0.65rem] font-black uppercase tracking-[0.4em] text-emerald-500">{tag}</span>
      </div>
      <span className="text-[0.65rem] font-black uppercase tracking-widest text-slate-600">{date}</span>
    </div>
    <h3 className="text-3xl font-black italic text-white mb-5 tracking-tight group-hover:text-emerald-400 transition-colors leading-none">{title}</h3>
    <p className="text-slate-500 text-sm font-medium leading-relaxed group-hover:text-slate-300 transition-colors">{desc}</p>
    <div className="absolute bottom-10 right-10 w-12 h-12 rounded-2xl bg-white/5 flex items-center justify-center opacity-0 group-hover:opacity-100 group-hover:scale-110 transition-all border border-emerald-500/20">
       <ArrowRight className="w-6 h-6 text-emerald-500" />
    </div>
  </motion.div>
);

const StepCard = ({ num, title, desc, icon: Icon, index }: any) => (
  <motion.div 
    initial={{ opacity: 0, scale: 0.9 }}
    whileInView={{ opacity: 1, scale: 1 }}
    viewport={{ once: true }}
    transition={{ delay: index * 0.2 }}
    className="relative group p-14 glass border-white/5 rounded-[4rem] text-center hover:bg-white/[0.02] transition-colors"
  >
    <div className="absolute -top-10 left-1/2 -translate-x-1/2 w-20 h-20 bg-emerald-500 text-black flex items-center justify-center rounded-[2rem] font-black text-3xl shadow-[0_0_40px_rgba(16,185,129,0.6)] rotate-[15deg] group-hover:rotate-0 transition-transform">
      {num}
    </div>
    <div className="mb-10 flex justify-center mt-6">
       <div className="w-20 h-20 rounded-3xl bg-white/5 flex items-center justify-center border border-white/10 group-hover:scale-110 group-hover:bg-emerald-500/10 transition-all">
          <Icon className="w-10 h-10 text-emerald-500" />
       </div>
    </div>
    <h4 className="text-2xl font-black text-white mb-5 uppercase italic tracking-tighter">{title}</h4>
    <p className="text-slate-500 text-base font-medium leading-relaxed group-hover:text-slate-300 transition-colors">{desc}</p>
  </motion.div>
);

// --- MAIN PAGE ---

export default function LandingPage() {
  const containerRef = useRef(null);
  const { scrollYProgress } = useScroll({ target: containerRef });
  const [chatStep, setChatStep] = useState(0);

  const opacityBanner = useTransform(scrollYProgress, [0, 0.1], [1, 0]);
  const scaleHero = useTransform(scrollYProgress, [0, 0.2], [1, 0.9]);

  useEffect(() => {
    const timer = setInterval(() => {
      setChatStep(prev => (prev + 1) % 3);
    }, 5000);
    return () => clearInterval(timer);
  }, []);
  
  return (
    <div ref={containerRef} className="min-h-screen relative selection:bg-emerald-500/40 bg-[#000205] font-inter overflow-hidden pb-32 transition-colors duration-1000">
      
      {/* Background Mesh */}
      <div className="bg-mesh" />

      {/* Hero Section */}
      <section className="relative min-h-screen flex flex-col items-center justify-center px-6 overflow-hidden">
        {/* Dynamic Glowing Aura */}
        <div className="absolute inset-0 z-0 pointer-events-none">
           <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-emerald-500/10 blur-[180px] rounded-full animate-pulse" />
           <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-blue-500/5 blur-[150px] rounded-full [animation-delay:2s]" />
        </div>

        <motion.div 
          style={{ opacity: opacityBanner, scale: scaleHero }}
          className="max-w-7xl w-full text-center space-y-20 relative z-10"
        >
          <div className="space-y-12">
            <motion.div 
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              className="inline-flex items-center gap-4 px-10 py-3 rounded-full glass border border-emerald-500/30 text-emerald-400 text-[0.7rem] font-black uppercase tracking-[0.6em] mb-4 shadow-[0_0_50px_rgba(16,185,129,0.1)]"
            >
              <Zap className="w-5 h-5 fill-emerald-500 animate-pulse" /> 0x4f2A Protocol Operational
            </motion.div>

            <div className="space-y-6">
              <motion.h1 
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
                className="text-4xl md:text-6xl lg:text-8xl font-black tracking-tight text-white leading-tight uppercase"
              >
                Wakil AI <br /> <span className="text-emerald-500">Welcome</span>
              </motion.h1>
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: 400 }}
                transition={{ duration: 2, delay: 0.8 }}
                className="h-1.5 bg-gradient-to-r from-transparent via-emerald-500 to-transparent mx-auto blur-[1px]"
              />
            </div>

            <motion.p 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1, duration: 1.5 }}
              className="text-slate-400 text-sm md:text-lg max-w-xl mx-auto font-medium leading-relaxed tracking-normal"
            >
              Professional Autonomous AI for Decision Support, 
              Strategic Analysis, and Seamless Integration into 
              Your Daily Workflow.
            </motion.p>
          </div>

          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.4 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-6 pt-10"
          >
            <Link href="/chat" className="w-full sm:w-auto px-10 py-4 bg-emerald-500 text-black text-[0.7rem] font-bold uppercase tracking-widest rounded-full hover:bg-white hover:scale-105 active:scale-95 transition-all shadow-lg flex items-center justify-center gap-4">
              Start Consultation <ArrowRight className="w-5 h-5" />
            </Link>
            <Link href="#features" className="w-full sm:w-auto px-10 py-4 glass text-white text-[0.7rem] font-bold uppercase tracking-widest rounded-full border border-white/10 hover:bg-white/5 transition-all flex items-center justify-center">
              Explore Features
            </Link>
          </motion.div>
        </motion.div>

        {/* Floating Icons Background */}
        <div className="absolute inset-0 -z-10 pointer-events-none opacity-20">
           <div className="absolute top-[20%] left-[10%]"><Cpu className="w-40 h-40 text-emerald-500 blur-sm animate-float" /></div>
           <div className="absolute bottom-[20%] right-[10%]"><Shield className="w-56 h-56 text-blue-500 blur-md animate-float" style={{ animationDelay: '2s' }} /></div>
           <div className="absolute top-[60%] right-[20%]"><Globe className="w-32 h-32 text-emerald-500 blur-xl animate-float" style={{ animationDelay: '4s' }} /></div>
        </div>

        {/* Scroll Indicator */}
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 2 }}
          className="absolute bottom-12 flex flex-col items-center gap-6"
        >
           <div className="w-px h-24 bg-gradient-to-b from-emerald-500 via-emerald-500/20 to-transparent" />
           <span className="text-[0.6rem] font-black uppercase tracking-[0.8em] text-emerald-500 rotate-90 translate-y-20">Scroll for Access</span>
        </motion.div>
      </section>

      {/* Dispatches (News) */}
      <section id="news" className="py-32 px-6 relative z-10">
        <div className="max-w-7xl mx-auto">
           <div className="flex flex-col md:flex-row justify-between items-end mb-32 gap-12">
              <div className="space-y-8 text-center md:text-left">
                 <h2 className="text-[0.75rem] font-black uppercase tracking-[0.8em] text-emerald-500">Core Relay Dispatches</h2>
                 <h3 className="text-5xl md:text-7xl font-black italic tracking-tighter text-white uppercase leading-[0.8]">Neural<br/>Activity.</h3>
              </div>
              <Link href="#" className="hidden md:flex text-[0.7rem] font-black uppercase tracking-[0.5em] glass px-12 py-6 rounded-full border border-white/10 text-slate-500 hover:text-emerald-500 hover:border-emerald-500/40 items-center gap-5 transition-all shadow-2xl">
                Access Archives <ArrowRight className="w-6 h-6" />
              </Link>
           </div>
           
           <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
              <NewsCard 
                 index={0}
                 tag="Infrastructure Status"
                 date="MAR 28, 2026"
                 title="Production Node Synchronized via Vercel"
                 desc="Platform V2.4 is officially globally redundant. Deployed with 100% architectural integrity across multiple high-speed neural regions."
              />
              <NewsCard 
                 index={1}
                 tag="Neural Enhancement"
                 date="MAR 27, 2026"
                 title="Barada Core Visual Core Activated"
                 desc="Synthesis of high-density visual constructs is now fully operational. Integrated direct stability-model pipelines within the Chat Hub."
              />
           </div>
        </div>
      </section>

      {/* Demo Section */}
      <section id="demo" className="py-48 px-6 relative overflow-hidden">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-[120%] bg-[#10b981]/[0.02] -skew-y-6" />
        <div className="max-w-6xl mx-auto relative">
          <motion.div 
            initial={{ opacity: 0, y: 100 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            className="glass border-white/5 rounded-[5rem] overflow-hidden shadow-[0_80px_200px_rgba(0,0,0,0.95)] relative group"
          >
             <div className="absolute -inset-1 bg-gradient-to-r from-emerald-500/20 to-transparent rounded-[5.1rem] blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-1000" />
             
             <div className="h-20 bg-white/[0.03] border-b border-white/5 flex items-center px-12 gap-8 relative z-10">
                <div className="flex gap-3">
                  <div className="w-4 h-4 rounded-full bg-red-500/20 border border-red-500/30" />
                  <div className="w-4 h-4 rounded-full bg-yellow-500/20 border border-yellow-500/30" />
                  <div className="w-4 h-4 rounded-full bg-emerald-500/40 border border-emerald-500/50" />
                </div>
                <div className="flex-1 text-center">
                  <span className="text-[0.7rem] font-black uppercase tracking-[0.8em] text-slate-600">Secure_Transmission_NODE_4F2A</span>
                </div>
             </div>
             
             <div className="h-[750px] bg-[#000205] p-16 flex flex-col gap-12 relative overflow-hidden z-10">
                <div className="absolute inset-0 bg-mesh opacity-10 pointer-events-none" />
                
                <AnimatePresence mode="wait">
                  {chatStep === 0 && (
                    <motion.div key="1" initial={{ opacity: 0, x: 50 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -50 }} className="space-y-12">
                      <div className="flex flex-row-reverse gap-10">
                        <div className="w-16 h-16 rounded-[1.5rem] bg-slate-900 border border-emerald-500/20 flex items-center justify-center overflow-hidden shadow-2xl"><img src="/profile.jpg" className="w-full h-full object-cover" /></div>
                        <div className="bg-emerald-500 text-black p-10 rounded-[4rem] rounded-tr-xl font-black text-lg shadow-[0_20px_60px_rgba(16,185,129,0.3)] max-w-lg">Execute neural logic for a decentralized finance protocol.</div>
                      </div>
                      <div className="flex gap-10">
                        <div className="w-16 h-16 rounded-[1.5rem] glass border border-emerald-500/30 flex items-center justify-center shrink-0 shadow-2xl relative">
                           <img src="/logo.png" className="w-10 h-10 object-contain" />
                           <div className="absolute -bottom-1.5 -right-1.5 w-5 h-5 bg-emerald-500 rounded-full border-[4px] border-[#000205] animate-pulse" />
                        </div>
                        <div className="glass p-12 rounded-[4rem] rounded-tl-xl border border-white/5 space-y-6 max-w-xl shadow-2xl backdrop-blur-3xl">
                           <div className="flex gap-4"><div className="w-3 h-3 rounded-full bg-emerald-500 animate-bounce" /><div className="w-3 h-3 rounded-full bg-emerald-500 animate-bounce" style={{ animationDelay: '200ms' }} /><div className="w-3 h-3 rounded-full bg-emerald-500 animate-bounce" style={{ animationDelay: '400ms' }} /></div>
                           <p className="text-sm font-black mono text-emerald-400 tracking-[0.3em] uppercase italic">Initializing high-fidelity logic block...</p>
                        </div>
                      </div>
                    </motion.div>
                  )}
                  {chatStep === 1 && (
                    <motion.div key="2" initial={{ opacity: 0, x: 50 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -50 }} className="space-y-12">
                      <div className="flex flex-row-reverse gap-10">
                        <div className="w-16 h-16 rounded-[1.5rem] bg-slate-900 border border-emerald-500/20 flex items-center justify-center overflow-hidden shadow-2xl"><img src="/profile.jpg" className="w-full h-full object-cover" /></div>
                        <div className="bg-emerald-500 text-black p-10 rounded-[4rem] rounded-tr-xl font-black text-lg shadow-[0_20px_60px_rgba(16,185,129,0.3)] max-w-lg">Synthesize a futuristic architectural vista.</div>
                      </div>
                      <div className="flex gap-10">
                        <div className="w-16 h-16 rounded-[1.5rem] glass border border-emerald-500/30 flex items-center justify-center shrink-0 shadow-2xl relative">
                           <img src="/logo.png" className="w-10 h-10 object-contain" />
                           <div className="absolute -bottom-1.5 -right-1.5 w-5 h-5 bg-emerald-500 rounded-full border-[4px] border-[#000205] animate-pulse" />
                        </div>
                        <div className="glass p-8 rounded-[4rem] rounded-tl-xl border border-white/5 space-y-8 max-w-md shadow-2xl backdrop-blur-3xl">
                           <div className="aspect-[4/3] bg-emerald-950/20 rounded-[3rem] animate-pulse flex flex-col items-center justify-center border border-emerald-500/10">
                              <Sparkles className="w-20 h-20 text-emerald-500/20 mb-4" />
                              <p className="text-[0.65rem] font-black uppercase tracking-[0.6em] text-emerald-500/40">Visualizing...</p>
                           </div>
                           <p className="text-center text-[0.7rem] font-black uppercase tracking-[0.5em] text-emerald-500">Neural Rendering Active</p>
                        </div>
                      </div>
                    </motion.div>
                  )}
                  {chatStep === 2 && (
                    <motion.div key="3" initial={{ opacity: 0, x: 50 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -50 }} className="space-y-12">
                      <div className="flex flex-row-reverse gap-10">
                        <div className="w-16 h-16 rounded-[1.5rem] bg-slate-900 border border-emerald-500/20 flex items-center justify-center overflow-hidden shadow-2xl"><img src="/profile.jpg" className="w-full h-full object-cover" /></div>
                        <div className="bg-emerald-500 text-black p-10 rounded-[4rem] rounded-tr-xl font-black text-lg shadow-[0_20px_60px_rgba(16,185,129,0.3)] max-w-lg">What is the Prime Directive of Wakil?</div>
                      </div>
                      <div className="flex gap-10">
                        <div className="w-16 h-16 rounded-[1.5rem] glass border border-emerald-500/30 flex items-center justify-center shrink-0 shadow-2xl relative">
                           <img src="/logo.png" className="w-10 h-10 object-contain" />
                           <div className="absolute -bottom-1.5 -right-1.5 w-5 h-5 bg-emerald-500 rounded-full border-[4px] border-[#000205] animate-pulse" />
                        </div>
                        <div className="glass p-12 rounded-[4rem] rounded-tl-xl border border-white/5 max-w-xl shadow-2xl backdrop-blur-3xl">
                           <div className="flex items-center gap-4 mb-8">
                             <Fingerprint className="w-6 h-6 text-emerald-500" />
                             <span className="text-[0.7rem] font-black uppercase tracking-[0.6em] text-emerald-500">Authenticating Query...</span>
                           </div>
                           <div className="space-y-4">
                             <div className="h-2.5 w-full bg-white/5 rounded-full overflow-hidden"><motion.div animate={{ x: ['-100%', '100%'] }} transition={{ duration: 2, repeat: Infinity }} className="h-full w-1/2 bg-emerald-500/20" /></div>
                             <div className="h-2.5 w-[90%] bg-white/5 rounded-full overflow-hidden"><motion.div animate={{ x: ['-100%', '100%'] }} transition={{ duration: 2, repeat: Infinity, delay: 0.5 }} className="h-full w-1/2 bg-emerald-500/10" /></div>
                             <div className="h-2.5 w-[75%] bg-white/5 rounded-full" />
                           </div>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>

                <div className="absolute inset-x-16 bottom-16">
                   <div className="glass h-24 rounded-[3.5rem] border-white/10 flex items-center px-12 text-slate-500 text-lg font-black uppercase tracking-[0.4em] group transition-all hover:border-emerald-500/50 cursor-pointer shadow-3xl backdrop-blur-4xl">
                      Standby for Command...
                      <div className="ml-auto w-12 h-12 rounded-2xl bg-emerald-500/10 flex items-center justify-center group-hover:bg-emerald-500 group-hover:text-black transition-all">
                        <Send className="w-6 h-6" />
                      </div>
                   </div>
                </div>
             </div>
          </motion.div>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="py-48 px-6 relative">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-40 space-y-12">
            <motion.h2 
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              className="text-[0.75rem] font-black uppercase tracking-[1em] text-emerald-500"
            >
              System Parameters
            </motion.h2>
            <motion.h3 
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              className="text-6xl md:text-8xl font-black italic tracking-tighter text-white uppercase leading-[0.8]"
            >
              Beyond <br /><span className="text-emerald-500 text-gradient">Limit.</span>
            </motion.h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-16">
            <FeatureCard 
              index={0}
              title="Visual Core" 
              desc="Deep synthetic rendering via Barada Neural infrastructure for high-density imagery." 
              icon={ImageIcon} 
            />
            <FeatureCard 
              index={1}
              title="Execution Node" 
              desc="Calculus-tier logic processing optimized for mission-critical architectural sync." 
              icon={Terminal} 
            />
            <FeatureCard 
              index={2}
              title="Search Relay" 
              desc="Real-time web synchronization with autonomous data verification and filtering." 
              icon={Globe} 
            />
            <FeatureCard 
              index={3}
              title="Aegis Protocol" 
              desc="Maximum security end-to-end encryption for every sovereign transmission." 
              icon={Shield} 
            />
            <FeatureCard 
              index={4}
              title="Auto Nexus" 
              desc="Self-optimizing task routing that evolves through every interaction." 
              icon={Workflow} 
            />
            <FeatureCard 
              index={5}
              title="Apex Interface" 
              desc="A futuristic minimalist design focused on professional velocity and absolute clarity." 
              icon={MousePointer2} 
            />
          </div>
        </div>
      </section>

      {/* Operational Flow */}
      <section id="process" className="py-48 px-6 relative border-y border-white/5 bg-emerald-500/[0.01]">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-48">
             <h3 className="text-6xl md:text-8xl font-black italic tracking-tighter text-white uppercase leading-[0.8]">The<br/>Protocol.</h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-24">
            <StepCard 
              num="01"
              index={0}
              title="Initialize"
              desc="Establish a connection with the Wakil node and transmit objective."
              icon={Fingerprint}
            />
            <StepCard 
              num="02"
              index={1}
              title="Synchronize"
              desc="Collaborative neural cores process and synthesize the execution path."
              icon={Activity}
            />
            <StepCard 
              num="03"
              index={2}
              title="Project"
              desc="Real-time delivery of high-fidelity results across all nodes."
              icon={Rocket}
            />
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-80 px-6 relative text-center">
         <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[1000px] h-[1000px] bg-emerald-500/[0.03] blur-[200px] rounded-full" />
         <div className="max-w-6xl mx-auto space-y-32 relative z-10">
            <motion.h2 
              initial={{ scale: 0.9, opacity: 0 }}
              whileInView={{ scale: 1, opacity: 1 }}
              transition={{ duration: 1 }}
              className="text-7xl md:text-9xl lg:text-[11rem] font-black italic tracking-tighter text-white uppercase leading-[0.7]"
            >
              SEIZE THE <br /><span className="text-emerald-500">VOICE.</span>
            </motion.h2>
            <Link href="/chat" className="inline-flex items-center gap-12 px-24 py-12 bg-white text-black text-lg font-black uppercase tracking-[0.6em] rounded-[4rem] hover:bg-emerald-500 hover:scale-110 active:scale-95 transition-all shadow-[0_40px_120px_rgba(255,255,255,0.1)] group">
              Connect Now <ArrowRight className="w-10 h-10 group-hover:translate-x-6 transition-transform" />
            </Link>
         </div>
      </section>

      {/* Footer */}
      <footer className="py-40 px-12 border-t border-white/5 relative z-10 glass rounded-t-[5rem]">
        <div className="max-w-7xl mx-auto space-y-32">
           <div className="flex flex-col lg:flex-row justify-between items-start gap-24">
              <div className="space-y-12">
                <div className="flex items-center gap-8">
                  <div className="flex items-center gap-4">
                    <img src="/logo.png" className="w-14 h-14 object-contain mix-blend-screen drop-shadow-[0_0_10px_#10b981]" alt="" />
                    <img src="/bard-logo.png" className="w-14 h-14 object-contain mix-blend-screen drop-shadow-[0_0_10px_#3b82f6]" alt="" />
                  </div>
                  <span className="text-4xl font-black italic tracking-tighter text-white uppercase">Wakil Node</span>
                </div>
                <p className="text-slate-500 font-medium max-w-md text-lg leading-relaxed uppercase tracking-wider">Defining the pinnacle of autonomous strategic intelligence since 2026.</p>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-24 lg:gap-32 w-full lg:w-auto">
                 <div className="space-y-10">
                    <h5 className="text-[0.8rem] font-black uppercase tracking-[0.4em] text-emerald-500">Core Relay</h5>
                    <div className="flex flex-col gap-6">
                       <Link href="/chat" className="text-sm font-black uppercase tracking-widest text-slate-500 hover:text-white transition-colors">Chat Hub</Link>
                       <Link href="/experience" className="text-sm font-black uppercase tracking-widest text-slate-500 hover:text-white transition-colors">Experience</Link>
                       <Link href="/about" className="text-sm font-black uppercase tracking-widest text-slate-500 hover:text-white transition-colors">Platform</Link>
                    </div>
                 </div>
                 <div className="space-y-10">
                    <h5 className="text-[0.8rem] font-black uppercase tracking-[0.4em] text-emerald-500">Governance</h5>
                    <div className="flex flex-col gap-6">
                       <Link href="/privacy" className="text-sm font-black uppercase tracking-widest text-slate-500 hover:text-white transition-colors">Privacy Node</Link>
                       <Link href="/terms" className="text-sm font-black uppercase tracking-widest text-slate-500 hover:text-white transition-colors">Terms of Use</Link>
                    </div>
                 </div>
                 <div className="space-y-10">
                    <h5 className="text-[0.8rem] font-black uppercase tracking-[0.4em] text-emerald-500">Node Sync</h5>
                    <div className="flex items-center gap-8 text-slate-500">
                       <Link href="mailto:admin@wakil-rd.de"><MessageSquare className="w-8 h-8 hover:text-emerald-500 transition-colors" /></Link>
                       <Link href="/"><Globe className="w-8 h-8 hover:text-emerald-500 transition-colors" /></Link>
                    </div>
                 </div>
              </div>
           </div>
           
           <div className="pt-24 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-12 opacity-50">
              <p className="text-[0.7rem] font-black uppercase tracking-[0.5em] text-slate-600">© 2026 Wakil AI · Powered by Barada Neural Node</p>
              <div className="flex items-center gap-6">
                 <Command className="w-5 h-5 text-emerald-500" />
                 <span className="text-[0.7rem] font-black uppercase tracking-[0.4em] text-emerald-500">Neural Integrity: Optimal</span>
              </div>
           </div>
        </div>
      </footer>

      {/* Global Aesthetics */}
      <style jsx global>{`
        .text-gradient {
           background: linear-gradient(135deg, #fff 0%, #10b981 100%);
           -webkit-background-clip: text;
           -webkit-text-fill-color: transparent;
        }
        .shadow-3xl {
           box-shadow: 0 40px 100px rgba(0, 0, 0, 0.8);
        }
        .backdrop-blur-4xl {
           backdrop-filter: blur(60px);
           -webkit-backdrop-filter: blur(60px);
        }
      `}</style>

    </div>
  );
}
