'use client';

import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Mail, Lock, User, ArrowRight, Loader2, ShieldCheck, Zap, Terminal } from 'lucide-react';
import { signIn } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';

export default function LoginPage() {
  const [isRegister, setIsRegister] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [formData, setFormData] = useState({ name: '', email: '', password: '' });
  const router = useRouter();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    try {
      if (isRegister) {
        // Register flow
        const res = await fetch('/api/register', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(formData),
        });
        const contentType = res.headers.get("content-type");
        let data;
        if (contentType && contentType.includes("application/json")) {
          data = await res.json();
        } else {
          const text = await res.text();
          throw new Error("Server error (Non-JSON response). Please check your Database/Turso configuration.");
        }

        if (!res.ok) throw new Error(data?.error || 'Registration failed');
        
        // Auto login after register
        const result = await signIn('credentials', {
          redirect: false,
          email: formData.email,
          password: formData.password,
        });

        if (result?.error) throw new Error('Could not log in after registration');
        router.push('/chat');
      } else {
        // Login flow
        const result = await signIn('credentials', {
          redirect: false,
          email: formData.email,
          password: formData.password,
        });

        if (result?.error) throw new Error('Invalid email or password');
        router.push('/chat');
      }
    } catch (err: any) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#020617] flex items-center justify-center p-6 relative overflow-hidden selection:bg-[#10b981]/30">
      {/* Background FX */}
      <div className="absolute top-0 left-0 w-full h-full bg-mesh opacity-20 pointer-events-none" />
      <div className="absolute top-1/4 left-1/4 w-[40%] h-[40%] bg-[#10b981]/5 blur-[120px] rounded-full animate-pulse" />

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md relative z-10"
      >
        <div className="glass p-10 rounded-[3rem] border-white/5 shadow-2xl space-y-8">
          <div className="text-center space-y-4">
            <motion.div 
               whileHover={{ rotate: 180 }}
               transition={{ duration: 0.5 }}
               className="w-20 h-20 bg-[#10b981]/10 rounded-3xl border border-[#10b981]/20 flex items-center justify-center mx-auto"
            >
               <img src="/logo.png" className="w-12 h-12 mix-blend-screen" alt="Wakil AI" />
            </motion.div>
            <h1 className="text-3xl font-black italic tracking-tighter text-white uppercase">
              {isRegister ? 'New Protocol' : 'Node Auth'}
            </h1>
            <p className="text-slate-500 text-[0.6rem] font-black uppercase tracking-[0.3em] flex items-center justify-center gap-2">
              <Zap className="w-3 h-3 text-[#10b981]" /> Encryption Mode: Active
            </p>
          </div>

          {error && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="p-4 bg-red-500/10 border border-red-500/20 rounded-2xl text-red-500 text-xs font-bold text-center italic"
            >
              {error}
            </motion.div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {isRegister && (
              <div className="relative group">
                <User className="absolute left-6 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500 group-focus-within:text-[#10b981] transition-colors" />
                <input 
                  type="text" 
                  placeholder="Full Name"
                  required
                  className="w-full pl-16 pr-6 py-5 glass border border-white/5 rounded-2xl outline-none focus:border-[#10b981]/30 text-white font-medium placeholder-slate-600 transition-all text-sm"
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                />
              </div>
            )}
            
            <div className="relative group">
              <Mail className="absolute left-6 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500 group-focus-within:text-[#10b981] transition-colors" />
              <input 
                type="email" 
                placeholder="Neural ID (Email)"
                required
                className="w-full pl-16 pr-6 py-5 glass border border-white/5 rounded-2xl outline-none focus:border-[#10b981]/30 text-white font-medium placeholder-slate-600 transition-all text-sm"
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              />
            </div>

            <div className="relative group">
              <Lock className="absolute left-6 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500 group-focus-within:text-[#10b981] transition-colors" />
              <input 
                type="password" 
                placeholder="Access Hash"
                required
                className="w-full pl-16 pr-6 py-5 glass border border-white/5 rounded-2xl outline-none focus:border-[#10b981]/30 text-white font-medium placeholder-slate-600 transition-all text-sm"
                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
              />
            </div>

            <button 
              type="submit"
              disabled={isLoading}
              className="w-full py-5 bg-[#10b981] text-black font-black uppercase tracking-[0.3em] rounded-2xl hover:bg-white hover:scale-102 active:scale-98 transition-all shadow-[0_20px_40px_rgba(16,185,129,0.2)] flex items-center justify-center gap-3"
            >
              {isLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : (
                <>
                  {isRegister ? 'Initialize Node' : 'Grant Session'}
                  <ArrowRight className="w-5 h-5" />
                </>
              )}
            </button>
          </form>

          <div className="pt-4 flex flex-col items-center gap-6">
            <p className="text-slate-500 text-[0.6rem] font-black uppercase tracking-widest">
              {isRegister ? 'Already have an ID?' : "Don't have a node ID?"}
              <button 
                onClick={() => setIsRegister(!isRegister)}
                className="ml-2 text-[#10b981] hover:text-white transition-colors"
              >
                {isRegister ? 'Sync Existing' : 'Register New'}
              </button>
            </p>
            
            <div className="w-full h-px bg-white/5" />
            
            <div className="flex gap-4">
                <div className="p-3 glass-light border border-white/5 rounded-xl text-slate-400 hover:text-[#10b981]/50 hover:border-[#10b981]/20 cursor-pointer transition-all">
                  <Terminal className="w-5 h-5" />
                </div>
               <div className="p-3 glass-light border border-white/5 rounded-xl text-slate-400 hover:text-[#10b981] hover:border-[#10b981]/20 cursor-pointer transition-all">
                  <ShieldCheck className="w-5 h-5" />
               </div>
            </div>
          </div>
        </div>
        
        <p className="text-center mt-10 text-[0.55rem] font-black uppercase tracking-[0.4em] text-slate-600">
           © 2026 Wakil AI Infrastructure · Secure Protocol Active
        </p>
      </motion.div>
    </div>
  );
}
