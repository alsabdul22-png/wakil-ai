import type { MetadataRoute } from 'next';

export default function robots(): MetadataRoute.Robots {
  return {
    rules: [
      {
        userAgent: '*',
        allow: '/',
        disallow: ['/api/', '/login/'],
      },
    ],
    sitemap: 'https://wakil-rd.de/sitemap.xml',
    host: 'https://wakil-rd.de',
  };
}
