import { NextResponse } from 'next/server';

export async function POST(req: Request) {
  const { prompt } = await req.json();
  
  if (!prompt) {
    return NextResponse.json({ error: 'Prompt is required' }, { status: 400 });
  }

  try {
    const HF_TOKEN = process.env.HF_IMAGE_TOKEN;
    
    // Attempt Hugging Face FLUX.1-schnell first
    if (HF_TOKEN) {
      console.log(`[ImageGen] Attempting Hugging Face with prompt: "${prompt.substring(0, 50)}..."`);
      const hfResponse = await fetch(
        'https://router.huggingface.co/hf-inference/models/black-forest-labs/FLUX.1-schnell/v1/images/generations',
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${HF_TOKEN}`,
          },
          body: JSON.stringify({
            prompt,
            num_inference_steps: 4,
            width: 1024,
            height: 1024,
          }),
        }
      );

      if (hfResponse.ok) {
        const data = await hfResponse.json();
        const b64 = data?.data?.[0]?.b64_json;
        if (b64) {
          return NextResponse.json({ b64_json: b64 });
        }
        
        const url = data?.data?.[0]?.url;
        if (url) {
          const imgRes = await fetch(url);
          const buffer = Buffer.from(await imgRes.arrayBuffer());
          return NextResponse.json({ b64_json: buffer.toString('base64') });
        }
      } else {
        const errText = await hfResponse.text().catch(() => 'Unknown error');
        console.warn(`[ImageGen] Hugging Face failed (Status: ${hfResponse.status}). Error: ${errText}`);
        
        // If it's 402 (Payment Required) or 429 (Too Many Requests), we MUST fall back
        if (hfResponse.status === 402 || hfResponse.status === 429) {
           console.log('[ImageGen] Falling back to Pollinations.ai (Free Provider)...');
        } else {
           // For other errors, we still fall back to ensure UX
           console.log('[ImageGen] Initiating fallback...');
        }
      }
    }

    // --- FALLBACK TO AI HORDE (STABLE HORDE) ---
    // AI Horde is a distributed community-run network that is FREE and doesn't require keys.
    // Anonymously we use API Key '0000000000'.
    console.log('[ImageGen] Falling back to AI Horde (Anonymous)...');

    const hordeResponse = await fetch('https://stablehorde.net/api/v2/generate/async', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'apikey': '0000000000',
        'Client-Agent': 'WakilAI:1.0:Agent'
      },
      body: JSON.stringify({
        prompt,
        params: {
          cfg_scale: 7.5,
          width: 512,
          height: 512,
          steps: 20,
          sampler_name: "k_euler"
        },
        models: ["stable_diffusion_xl_base_1.0", "stable_diffusion"]
      })
    });

    if (!hordeResponse.ok) {
       throw new Error(`AI Horde initial error: ${hordeResponse.status}`);
    }

    const { id } = await hordeResponse.json();
    console.log(`[ImageGen] Horde Job ID: ${id}. Waiting for generation...`);

    // Poll for results (max 60 seconds)
    let solved = false;
    let attempts = 0;
    let b64_json = '';

    while (!solved && attempts < 30) {
      await new Promise(r => setTimeout(r, 2000)); // Wait 2s
      attempts++;
      
      const checkRes = await fetch(`https://stablehorde.net/api/v2/generate/check/${id}`);
      const checkData = await checkRes.json();
      
      console.log(`[ImageGen] Horde Polling... Attempt ${attempts}, Done: ${checkData.done}, Waiting: ${checkData.wait_time}s`);
      
      if (checkData.done) {
        const finalRes = await fetch(`https://stablehorde.net/api/v2/generate/status/${id}`);
        const finalData = await finalRes.json();
        
        if (finalData.generations?.[0]?.img) {
          // AI Horde returns image in its own format, but often base64 or URL
          // If it's a URL, we fetch it. If it's img (base64 or URL), handle it.
          const imgSource = finalData.generations[0].img;
          if (imgSource.startsWith('http')) {
             const imgFetch = await fetch(imgSource);
             const buffer = Buffer.from(await imgFetch.arrayBuffer());
             b64_json = buffer.toString('base64');
          } else {
             b64_json = imgSource; // Already base64
          }
          solved = true;
          console.log('[ImageGen] Horde Success!');
        } else {
          throw new Error('AI Horde returned no image in status response.');
        }
      }
    }

    if (!solved) {
      throw new Error('AI Horde took too long or failed.');
    }

    return NextResponse.json({ b64_json });

  } catch (error: any) {
    console.error('[ImageGen] Critical Error:', error.message);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
