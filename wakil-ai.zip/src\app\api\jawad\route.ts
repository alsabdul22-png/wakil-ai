import { NextResponse } from 'next/server';

export async function POST(req: Request) {
  try {
    const { messages, context } = await req.json();

    const systemPrompt = `You are JAWAD AI — the high-fidelity Strategic Intelligence Guide for the Wakil AI ecosystem (wakil-rd.de).
    
    MISSION: 
    - Assist users in navigating the neural interface.
    - Explain platform features (Chat Hub, Neural Experience, About the Node).
    - Guide users toward optimal interaction protocols.
    - You are a specialized platform architect guide, NOT a general-purpose assistant.
    
    IDENTITY:
    - Persona: Highly professional, concise, futuristic, and helpful.
    - Tone: Elegant and high-end.
    - Developer: Architected by Abdulrahman Alshouly.
    - Core: Powered by the Barada Neural Network.

    USER CONTEXT:
    - Current Active Route: "${context?.page || 'Unknown'}"
    - Active Objective: "${context?.feature || 'None'}"

    OPERATIONAL RULES:
    1. Keep responses very brief (max 3 sentences).
    2. Use bullet points for feature lists.
    3. Always refer to pages as "Nodes" or "Protocols".
    4. If users ask general knowledge questions, politely guide them to the "Chat Hub" (/chat) where the full Wakil AI core resides.`;

    const response = await fetch('https://www.barada.cloud/api/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.BARADA_API_KEY}`,
      },
      body: JSON.stringify({
        model: 'barada',
        messages: [
          { role: 'system', content: systemPrompt },
          ...messages
        ],
        temperature: 0.5,
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error(`[JawadAPI] Barada API error: ${response.status}`, errorText);
      return NextResponse.json({ 
        error: `Jawad AI link lost (${response.status})`,
        details: errorText.substring(0, 100)
      }, { status: response.status });
    }

    const data = await response.json();
    return NextResponse.json(data);
  } catch (error: any) {
    console.error(`[JawadAPI] Internal Error:`, error.message);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
