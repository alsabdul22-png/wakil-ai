import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Wakil AI Experience – Interactive Neural Challenge',
  description:
    'Test your neural processing speed in the Wakil AI Logic Sync challenge. Track your progress, unlock achievements, and compete in adaptive difficulty modes: Beginner, Explorer, and Pro.',
  openGraph: {
    title: 'Wakil AI Experience – Interactive Neural Challenge',
    description:
      'Play the AI Logic Sync challenge on Wakil AI. Track scores, unlock achievements, and experience adaptive neural gameplay.',
    url: 'https://wakil-rd.de/experience',
  },
  alternates: {
    canonical: 'https://wakil-rd.de/experience',
  },
};

export default function ExperienceLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}
