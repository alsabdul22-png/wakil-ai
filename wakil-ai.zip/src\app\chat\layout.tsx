import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Chat with Wakil AI – Neural Intelligence Interface',
  description:
    'Start a conversation with Wakil AI. Use Chat, Image Generation, Deep Research, or Code Mode — powered by Barada Neural Networks for instant, high-quality responses.',
  openGraph: {
    title: 'Chat with Wakil AI – Neural Intelligence Interface',
    description:
      'Interact with Wakil AI using Chat, Image, Research, or Code modes. Powered by Barada AI for autonomous, high-fidelity responses.',
    url: 'https://wakil-rd.de/chat',
  },
  alternates: {
    canonical: 'https://wakil-rd.de/chat',
  },
};

export default function ChatLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}
