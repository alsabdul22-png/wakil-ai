import { NextResponse } from 'next/server';

export async function POST(req: Request) {
  try {
    const { prompt } = await req.json();

    const routingResponse = await fetch('https://www.barada.cloud/api/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.BARADA_API_KEY}`,
      },
      body: JSON.stringify({
        model: 'barada',
        messages: [
          {
            role: 'system',
            content: `You are a strict routing AI. The user will give a prompt. Determine if the user wants to generate/create an image, picture, photo, or graphic. If they want an image generated, output strictly exactly the word "IMAGE". Otherwise, output strictly exactly the word "TEXT". Say nothing else.`
          },
          { role: 'user', content: prompt }
        ],
        temperature: 0.1,
      }),
    });

    if (!routingResponse.ok) {
      const errorText = await routingResponse.text();
      console.error(`[AI-Routing] Barada API error: ${routingResponse.status}`, errorText);
      return NextResponse.json({ type: 'text', error: 'Routing failed' });
    }

    const routingData = await routingResponse.json();
    const intent = routingData.choices?.[0]?.message?.content?.trim().toUpperCase();

    return NextResponse.json({ type: intent === 'IMAGE' ? 'image' : 'text' });
  } catch (error: any) {
    console.error(`[AI-Routing] Internal Error:`, error.message);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
