import type { Metadata } from 'next';
import { Inter, Outfit } from 'next/font/google';
import { Analytics } from '@vercel/analytics/react';
import './globals.css';
import ClientLayout from '../components/ClientLayout';

const inter = Inter({ subsets: ['latin'], variable: '--font-inter' });
const outfit = Outfit({ subsets: ['latin'], variable: '--font-outfit' });

export const metadata: Metadata = {
  metadataBase: new URL('https://wakil-rd.de'),
  title: {
    default: 'Wakil AI – Premium Autonomous AI Assistant | Barada Intelligence',
    template: '%s | Wakil AI',
  },
  description:
    'Wakil AI is a premium autonomous AI assistant powered by Barada Neural Networks. Chat, generate images, search the web, and write code with cutting-edge AI technology.',
  keywords: [
    'Wakil AI', 'Barada AI', 'AI assistant', 'AI chat', 'image generation',
    'autonomous AI', 'neural network', 'AI platform', 'Germany AI',
  ],
  authors: [{ name: 'Wakil AI', url: 'https://wakil-rd.de' }],
  creator: 'Wakil AI',
  openGraph: {
    type: 'website',
    locale: 'en_US',
    url: 'https://wakil-rd.de',
    siteName: 'Wakil AI',
    title: 'Wakil AI – Premium Autonomous AI Assistant',
    description:
      'Experience next-generation AI with Wakil AI. Powered by Barada Neural Networks for chat, image synthesis, deep research, and code generation.',
    images: [
      {
        url: '/og-image.png',
        width: 1200,
        height: 630,
        alt: 'Wakil AI – Premium Autonomous AI Assistant',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Wakil AI – Premium Autonomous AI Assistant',
    description:
      'Experience next-generation AI with Wakil AI. Powered by Barada Neural Networks.',
    images: ['/og-image.png'],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
    },
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className={`${inter.variable} ${outfit.variable} scroll-smooth`}>
      <body className="min-h-screen bg-[#000205] text-slate-200 overflow-x-hidden selection:bg-emerald-500/30 font-inter">
        <ClientLayout>{children}</ClientLayout>
        <Analytics />
      </body>
    </html>
  );
}
