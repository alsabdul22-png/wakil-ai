// ==========================================
// WAKIL AI - Premium Embeddable Widget (Light Mode)
// ==========================================

window.addEventListener('DOMContentLoaded', () => {
  // 1. إنشاء نافذة الشات وستايل الـ Widget (Light Glassmorphism)
  const style = document.createElement('style');
  style.innerHTML = `
    #wakil-widget-container {
      position: fixed;
      bottom: 20px;
      right: 20px;
      z-index: 999999;
      font-family: sans-serif;
    }
    #wakil-chat-box {
      display: none;
      width: 300px;
      height: 400px;
      background: rgba(255, 255, 255, 0.8);
      backdrop-filter: blur(10px);
      -webkit-backdrop-filter: blur(10px);
      border: 1px solid rgba(255, 255, 255, 0.6);
      border-radius: 12px;
      box-shadow: 0 4px 15px rgba(0,0,0,0.2);
      flex-direction: column;
      overflow: hidden;
      transition: all 0.3s ease;
      margin-bottom: 20px;
    }
    #wakil-chat-header {
      background: linear-gradient(to right, rgba(16,185,129,0.15), rgba(255,255,255,0.5));
      padding: 15px;
      border-bottom: 1px solid rgba(0,0,0,0.05);
      color: #333;
      display: flex;
      align-items: center;
      gap: 10px;
      font-weight: bold;
    }
    #wakil-chat-header img {
      width: 24px;
      height: 24px;
      border-radius: 50%;
      box-shadow: 0 0 5px rgba(0,0,0,0.1);
    }
    #wakil-messages {
      flex: 1;
      padding: 15px;
      overflow-y: auto;
      display: flex;
      flex-direction: column;
      gap: 10px;
    }
    .wakil-msg {
      max-width: 85%;
      padding: 10px 14px;
      border-radius: 12px;
      font-size: 14px;
      line-height: 1.5;
      color: #333;
    }
    .wakil-msg.user {
      align-self: flex-end;
      background: rgba(0,0,0,0.05);
      border: 1px solid rgba(0,0,0,0.05);
    }
    .wakil-msg.ai {
      align-self: flex-start;
      background: rgba(16,185,129,0.15);
      border: 1px solid rgba(16,185,129,0.2);
    }
    #wakil-input-area {
      padding: 10px;
      background: transparent;
      border-top: 1px solid rgba(0,0,0,0.05);
    }
    #wakil-input {
      width: 100%;
      background: rgba(255,255,255,0.6);
      border: 1px solid rgba(0,0,0,0.1);
      color: #333;
      padding: 10px;
      border-radius: 20px;
      outline: none;
      font-size: 14px;
      box-sizing: border-box;
    }
    #wakil-input:focus {
      border-color: #10b981;
      background: #fff;
    }
    #wakil-toggle-btn {
      position: absolute;
      bottom: 0;
      right: 0;
      width: 60px;
      height: 60px;
      border-radius: 50%;
      background: #fff;
      border: 1px solid rgba(0,0,0,0.08);
      cursor: pointer;
      box-shadow: 0 4px 15px rgba(0,0,0,0.15);
      display: flex;
      align-items: center;
      justify-content: center;
      transition: transform 0.2s;
      z-index: 2;
    }
    #wakil-toggle-btn:hover {
      transform: scale(1.05);
    }
  `;
  document.head.appendChild(style);

  // إنشاء العناصر في HTML
  const container = document.createElement('div');
  container.id = 'wakil-widget-container';
  
  container.innerHTML = `
    <div id="wakil-chat-box">
      <div id="wakil-chat-header">
        <img src="http://localhost:3000/logo.png" alt="Logo" />
        <span>Wakil AI</span>
      </div>
      <div id="wakil-messages"></div>
      <div id="wakil-input-area">
        <input id="wakil-input" placeholder="Type 'get start' to begin..." autocomplete="off">
      </div>
    </div>
    <button id="wakil-toggle-btn">
      <svg fill="#10b981" width="28" height="28" viewBox="0 0 24 24"><path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2z"></path></svg>
    </button>
  `;
  document.body.appendChild(container);

  // 2. كشف اللغة
  let userLanguage = navigator.language || 'en';
  let chatStarted = false;

  // 3. سجل التفاعل (للمطورين)
  const logInteraction = (msg) => console.log(`[Wakil Widget] User [${userLanguage}]: ${msg}`);

  const chatBox = document.getElementById('wakil-chat-box');
  const toggleBtn = document.getElementById('wakil-toggle-btn');
  const input = document.getElementById('wakil-input');
  const messagesEl = document.getElementById('wakil-messages');

  // فتح وإغلاق النافذة
  toggleBtn.addEventListener('click', () => {
    const isHidden = chatBox.style.display === 'none' || chatBox.style.display === '';
    chatBox.style.display = isHidden ? 'flex' : 'none';
    if (isHidden) input.focus();
  });

  const appendMessage = (text, role) => {
    const div = document.createElement('div');
    div.className = "wakil-msg " + role;
    div.innerText = text;
    messagesEl.appendChild(div);
    messagesEl.scrollTop = messagesEl.scrollHeight;
  };

  // 4. التعامل مع إدخال المستخدم
  input.addEventListener('keypress', async (e) => {
    if(e.key === 'Enter') {
      const value = input.value.trim();
      if(!value) return;
      
      logInteraction(value);
      appendMessage(value, 'user');
      input.value = '';

      // إذا لم يبدأ المحادثة بعد
      if(!chatStarted && value.toLowerCase() === 'get start') {
        startChat();
        return;
      }

      if (chatStarted) {
        // جلب الرد من API الخاص בـ Next.js
        appendMessage('...', 'ai'); // Loading indicator
        
        try {
          const res = await fetch('http://localhost:3000/api/chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ messages: [{ role: 'user', content: value }] })
          });
          const data = await res.json();
          
          // Remove loading
          messagesEl.removeChild(messagesEl.lastChild);
          
          const aiText = data.choices?.[0]?.message?.content || "Error generating response.";
          appendMessage(aiText, 'ai');
        } catch(err) {
           messagesEl.removeChild(messagesEl.lastChild);
           appendMessage('Error connecting to Wakil AI API.', 'ai');
        }
      } else {
           appendMessage("Please type 'get start' to unlock the chat.", 'ai');
      }
    }
  });

  function startChat() {
    chatStarted = true;
    input.placeholder = "Ask Wakil AI anything...";
    
    const welcomeText = userLanguage.startsWith('ar') 
      ? "🤖 أهلاً بك! أنا وكيل الذكاء الاصطناعي، كيف يمكنني مساعدتك؟" 
      : "🤖 Welcome! Let's start chatting. How can I help you today?";
      
    appendMessage(welcomeText, 'ai');
  }
});
