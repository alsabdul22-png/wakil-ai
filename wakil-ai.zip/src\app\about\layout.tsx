import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'About Wakil AI – Platform Overview & Mission',
  description:
    'Learn about Wakil AI and the Barada Neural Network. Discover the architectural philosophy, team, and mission behind the most advanced autonomous AI assistant from Rendsburg, Germany.',
  openGraph: {
    title: 'About Wakil AI – Platform Overview & Mission',
    description:
      'Discover the team and mission behind Wakil AI. Built on Barada AI neural infrastructure for unprecedented reasoning depth.',
    url: 'https://wakil-rd.de/about',
  },
  alternates: {
    canonical: 'https://wakil-rd.de/about',
  },
};

export default function AboutLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}
