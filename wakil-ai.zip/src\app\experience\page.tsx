'use client';

import React, { useState, useEffect, useCallback, useRef } from 'react';
import { motion, AnimatePresence, useScroll, useSpring } from 'framer-motion';
import { 
  Zap, Trophy, Target, Cpu, Activity, Layout, 
  ChevronRight, Star, Shield, PlayCircle, BarChart3,
  CheckCircle2, Fingerprint, Eye, MousePointer2, Sparkles, BrainCircuit, Rocket, Command
} from 'lucide-react';

const cn = (...classes: any[]) => classes.filter(Boolean).join(' ');

type UserMode = 'Beginner' | 'Explorer' | 'Pro';
type Achievement = { id: string; title: string; icon: any; color: string; unlocked: boolean; description: string };

export default function AdaptiveExperience() {
  const [mode, setMode] = useState<UserMode>('Explorer');
  const [score, setScore] = useState(0);
  const [level, setLevel] = useState(1);
  const [experience, setExperience] = useState(0);
  const [gameActive, setGameActive] = useState(false);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const [sessionActs, setSessionActs] = useState(0);
  const [showBadge, setShowBadge] = useState<string | null>(null);

  const [achievements, setAchievements] = useState<Achievement[]>([
    { id: '1', title: 'Neural Link', icon: Zap, color: 'text-emerald-400', unlocked: true, description: 'Established neural connection.' },
    { id: '2', title: 'Calculus God', icon: Cpu, color: 'text-emerald-400', unlocked: false, description: 'Reach Level 5 in logic sync.' },
    { id: '3', title: 'Aegis Protocol', icon: Shield, color: 'text-emerald-400', unlocked: false, description: 'Complete challenge without errors.' },
    { id: '4', title: 'Overclocked', icon: Sparkles, color: 'text-emerald-400', unlocked: false, description: 'Maintain x10 combo streak.' },
  ]);

  const [gamePrompt, setGamePrompt] = useState({ question: '', answer: '', options: [] as string[] });
  const [gameTimer, setGameTimer] = useState(10);
  const [combo, setCombo] = useState(0);
  const [aiFeedback, setAiFeedback] = useState("Awaiting Command...");

  // Progress logic
  useEffect(() => {
    const requiredXp = level * 100;
    if (experience >= requiredXp) {
      setExperience(experience - requiredXp);
      setLevel(l => l + 1);
      if (level + 1 === 5) unlockAchievement('Calculus God');
    }
  }, [experience, level]);

  const unlockAchievement = (title: string) => {
    setAchievements(prev => prev.map(a => {
        if (a.title === title && !a.unlocked) {
            setShowBadge(title);
            setTimeout(() => setShowBadge(null), 3000);
            return { ...a, unlocked: true };
        }
        return a;
    }));
  };

  const handleGlobalInteraction = useCallback((e: React.MouseEvent) => {
    setSessionActs(s => s + 1);
    setExperience(exp => exp + 1);
    setMousePos({ x: e.clientX, y: e.clientY });
  }, []);

  // Mini-Game Logic
  const generatePuzzle = useCallback(() => {
    const ops = mode === 'Pro' ? ['+', '-', '*', '/'] : ['+', '-', '*'];
    const op = ops[Math.floor(Math.random() * ops.length)];
    const a = Math.floor(Math.random() * (mode === 'Pro' ? 30 : 15)) + 5;
    const b = Math.floor(Math.random() * (mode === 'Pro' ? 20 : 10)) + 2;
    
    let result = 0;
    if (op === '+') result = a + b;
    else if (op === '-') result = a - b;
    else if (op === '*') result = a * b;
    else if (op === '/') {
        result = a;
        setGamePrompt({
            question: `${(a * b)} ÷ ${b}`,
            answer: a.toString(),
            options: [a.toString(), (a + 2).toString(), (a - 1).toString(), (a + 4).toString()].sort(() => Math.random() - 0.5)
        });
        return;
    }
    
    const options = Array.from(new Set([result, result + 5, result - Math.floor(Math.random() * 5 + 1), result + 15]))
      .sort(() => Math.random() - 0.5);
    
    setGamePrompt({
      question: `${a} ${op === '*' ? '×' : op} ${b}`,
      answer: result.toString(),
      options: options.map(o => o.toString())
    });
  }, [mode]);

  const submitAnswer = (ans: string) => {
    if (ans === gamePrompt.answer) {
      setScore(s => s + (10 * (combo + 1)));
      setExperience(e => e + 25);
      setCombo(c => {
          const next = c + 1;
          if (next >= 10) unlockAchievement('Overclocked');
          return next;
      });
      setAiFeedback(Math.random() > 0.5 ? "Link Optimized!" : "Precision Verified.");
      generatePuzzle();
      setGameTimer(10);
    } else {
      setCombo(0);
      setAiFeedback("Synchronization Failure.");
      setGameActive(false);
    }
  };

  useEffect(() => {
    let t: any;
    if (gameActive && gameTimer > 0) {
      t = setInterval(() => setGameTimer(curr => curr - 1), 1000);
    } else if (gameActive && gameTimer === 0) {
      setGameActive(false);
      setCombo(0);
    }
    return () => clearInterval(t);
  }, [gameActive, gameTimer]);

  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, { stiffness: 100, damping: 30, restDelta: 0.001 });

  return (
    <div 
      className={cn(
        "min-h-screen transition-all duration-1000 bg-[#000205] text-slate-100 selection:bg-emerald-500/30 overflow-x-hidden font-inter",
        mode === 'Pro' ? "contrast-[1.1]" : mode === 'Beginner' ? "sepia-[0.05]" : ""
      )}
      onMouseMove={handleGlobalInteraction}
    >
      {/* GLOBAL PROGRESS BAR (TOP) */}
      <motion.div className="fixed top-0 left-0 right-0 h-1.5 bg-emerald-500 z-[100] origin-left shadow-[0_0_20px_rgba(16,185,129,0.8)]" style={{ scaleX }} />

      {/* DYNAMIC BACKGROUND */}
      <div className="fixed inset-0 pointer-events-none z-0">
         <div className="bg-mesh opacity-30" />
         <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_var(--x)_var(--y),_rgba(16,185,129,0.06)_0%,_transparent_50%)]" 
              style={{ '--x': `${mousePos.x}px`, '--y': `${mousePos.y}px` } as any} />
      </div>

      {/* ADAPTIVE NAV */}
      <nav className="fixed top-0 left-0 right-0 z-50 p-8 flex items-center justify-between pointer-events-none">
         <motion.div initial={{ y: -50, opacity: 0 }} animate={{ y: 0, opacity: 1 }} className="glass px-10 py-4 rounded-[1.5rem] flex items-center gap-8 border border-white/5 shadow-3xl pointer-events-auto">
            <div className="flex items-center gap-4">
               <div className="w-10 h-10 rounded-xl bg-emerald-500 flex items-center justify-center text-black shadow-glow">
                  <Fingerprint className="w-6 h-6" />
               </div>
               <div>
                  <p className="text-[0.5rem] font-black text-slate-500 uppercase tracking-widest leading-none">Access Level</p>
                  <p className="text-sm font-black text-white italic mt-0.5">NODE_{level.toString().padStart(2, '0')}</p>
               </div>
            </div>
            <div className="h-6 w-px bg-white/10" />
            <div className="flex items-center gap-4">
               <Activity className="w-5 h-5 text-emerald-500 animate-pulse" />
               <p className="text-[0.65rem] font-black uppercase tracking-[0.2em]">{sessionActs} ACTS_LIVE</p>
            </div>
         </motion.div>

         <div className="flex gap-2 p-2 glass rounded-[1.5rem] border border-white/5 pointer-events-auto">
            {(['Beginner', 'Explorer', 'Pro'] as UserMode[]).map(m => (
              <button 
                key={m} 
                onClick={() => setMode(m)}
                className={cn(
                  "px-8 py-3 rounded-xl text-[0.6rem] font-black uppercase tracking-widest transition-all",
                  mode === m ? "bg-emerald-500 text-black shadow-glow scale-105" : "text-slate-500 hover:text-slate-300"
                )}
              >
                {m}
              </button>
            ))}
         </div>
      </nav>

      <main className="relative z-10 pt-48 px-12 max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-16 pb-48">
        
        {/* DASHBOARD (LEFT) */}
        <div className="lg:col-span-4 space-y-12">
           <motion.div initial={{ x: -20, opacity: 0 }} animate={{ x: 0, opacity: 1 }} className="glass p-14 rounded-[4rem] border-white/5 relative overflow-hidden group shadow-3xl">
              <div className="absolute -top-10 -right-10 opacity-5 group-hover:opacity-10 transition-opacity">
                 <BrainCircuit className="w-48 h-48 text-emerald-500" />
              </div>
              <h2 className="text-[0.7rem] font-black uppercase tracking-[0.4em] text-emerald-500 mb-10 flex items-center gap-4">
                 <Layout className="w-5 h-5" /> Neural Sync Status
              </h2>
              
              <div className="flex items-center gap-10 mb-14">
                 <div className="relative">
                    <svg className="w-32 h-32 transform -rotate-90">
                       <circle cx="64" cy="64" r="60" stroke="currentColor" strokeWidth="8" fill="transparent" className="text-white/5" />
                       <motion.circle 
                          cx="64" cy="64" r="60" stroke="currentColor" strokeWidth="8" fill="transparent" 
                          strokeDasharray={377}
                          animate={{ strokeDashoffset: 377 - (377 * experience) / (level * 100) }}
                          className="text-emerald-500 drop-shadow-[0_0_10px_#10b981]"
                       />
                    </svg>
                    <div className="absolute inset-0 flex flex-col items-center justify-center">
                       <span className="text-4xl font-black italic">{level}</span>
                       <span className="text-[0.45rem] font-black uppercase text-slate-500 leading-none">LVL</span>
                    </div>
                 </div>
                 <div className="space-y-6 flex-1">
                    <div>
                       <p className="text-[0.6rem] font-black uppercase text-slate-500 mb-1">Score Matrix</p>
                       <p className="text-4xl font-black italic text-white tracking-tighter">{score.toLocaleString()}</p>
                    </div>
                    <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden border border-white/5">
                       <motion.div animate={{ width: `${(experience / (level * 100)) * 100}%` }} className="h-full bg-emerald-500 shadow-glow" />
                    </div>
                 </div>
              </div>

              <div className="grid grid-cols-2 gap-6">
                 <div className="p-6 bg-white/5 rounded-3xl border border-white/5 hover:border-emerald-500/20 transition-all">
                    <p className="text-[0.55rem] font-black uppercase text-slate-600 mb-2 tracking-widest">Node Sync</p>
                    <p className="text-lg font-bold text-emerald-400">99.2 %</p>
                 </div>
                 <div className="p-6 bg-white/5 rounded-3xl border border-white/5 hover:border-emerald-500/20 transition-all">
                    <p className="text-[0.55rem] font-black uppercase text-slate-600 mb-2 tracking-widest">Combo</p>
                    <p className="text-lg font-bold text-emerald-400">x{combo > 0 ? combo : 1}</p>
                 </div>
              </div>
           </motion.div>

           <div className="glass p-14 rounded-[4rem] border-white/5 shadow-3xl">
              <h2 className="text-[0.7rem] font-black uppercase tracking-[0.4em] text-emerald-400 mb-10 flex items-center gap-4">
                 <Trophy className="w-5 h-5" /> Performance Logs
              </h2>
              <div className="grid grid-cols-2 gap-4">
                 {achievements.map(ach => (
                    <motion.div 
                      key={ach.id}
                      whileHover={{ scale: 1.05 }}
                      className={cn(
                        "p-6 rounded-[2rem] border transition-all relative overflow-hidden",
                        ach.unlocked ? "bg-white/5 border-emerald-500/10" : "bg-black/40 border-white/5 opacity-30 grayscale"
                      )}
                    >
                       <ach.icon className={cn("w-7 h-7 mb-4", ach.unlocked ? "text-emerald-500" : "text-slate-600")} />
                       <p className="text-[0.7rem] font-black uppercase tracking-widest leading-none mb-2">{ach.title}</p>
                       <p className="text-[0.45rem] font-medium text-slate-600 uppercase tracking-tighter">{ach.description}</p>
                       {ach.unlocked && <div className="absolute top-4 right-4"><CheckCircle2 className="w-4 h-4 text-emerald-500" /></div>}
                    </motion.div>
                 ))}
              </div>
           </div>
        </div>

        {/* CORE INTERACTIVE (CENTER) */}
        <div className="lg:col-span-8 space-y-12">
           <AnimatePresence mode="wait">
             {!gameActive ? (
               <motion.div 
                 key="launcher" 
                 initial={{ opacity: 0, scale: 0.95 }} 
                 animate={{ opacity: 1, scale: 1 }} 
                 exit={{ opacity: 0, scale: 1.02 }}
                 className="glass p-24 rounded-[5rem] border-white/5 flex flex-col items-center text-center space-y-16 relative overflow-hidden shadow-3xl min-h-[600px] justify-center"
               >
                  <div className="absolute inset-x-0 top-0 h-1.5 bg-gradient-to-r from-transparent via-emerald-500/50 to-transparent" />
                  <div className="w-40 h-40 bg-emerald-500/10 rounded-[3rem] border border-emerald-500/20 flex items-center justify-center group cursor-pointer hover:rotate-12 transition-all shadow-glow">
                     <Target className="w-20 h-20 text-emerald-400 group-hover:scale-110 transition-transform" />
                  </div>
                  <div className="space-y-8">
                     <h2 className="text-6xl md:text-8xl font-black italic tracking-tighter text-white uppercase leading-[0.8]">Neural <br/><span className="text-emerald-500 text-gradient">Challenge.</span></h2>
                     <p className="text-slate-500 text-xl font-medium max-w-xl mx-auto leading-relaxed uppercase tracking-wider">
                        Synchronize your cognitive flow with the Wakil Core. 
                        Testing neural processing velocity for protocol access.
                     </p>
                  </div>
                  <button 
                    onClick={() => { generatePuzzle(); setGameActive(true); }}
                    className="group relative px-20 py-10 bg-white text-black font-black uppercase tracking-[0.6em] text-[0.8rem] rounded-[2.5rem] hover:bg-emerald-500 hover:scale-110 active:scale-95 transition-all shadow-glow overflow-hidden"
                  >
                     <span className="relative z-10 flex items-center gap-6">
                        <PlayCircle className="w-8 h-8" /> Initiate Link
                     </span>
                  </button>
               </motion.div>
             ) : (
               <motion.div 
                 key="game" 
                 initial={{ opacity: 0, scale: 1.05 }} 
                 animate={{ opacity: 1, scale: 1 }} 
                 className="glass p-24 rounded-[5rem] border-white/5 relative overflow-hidden backdrop-blur-4xl shadow-[0_80px_200px_rgba(0,0,0,0.9)]"
               >
                  <div className="flex justify-between items-center mb-32">
                     <div className="space-y-6">
                        <p className="text-[0.75rem] font-black uppercase text-slate-500 tracking-[0.6em]">Sync_Window</p>
                        <div className="flex items-center gap-12">
                           <h3 className={cn("text-8xl font-black italic tracking-tighter transition-all", gameTimer <= 3 ? "text-red-500 scale-110" : "text-emerald-400")}>
                             {gameTimer}s
                           </h3>
                           <div className="w-80 h-3 bg-white/5 rounded-full overflow-hidden border border-white/5 relative">
                              <motion.div animate={{ width: `${(gameTimer / 10) * 100}%` }} className={cn("h-full transition-colors shadow-glow", gameTimer <= 3 ? "bg-red-500" : "bg-emerald-500")} />
                           </div>
                        </div>
                     </div>
                     <div className="text-right space-y-4">
                        <p className="text-[0.75rem] font-black uppercase text-slate-500 tracking-[0.6em]">Feedback</p>
                        <motion.p key={aiFeedback} initial={{ y: 10, opacity: 0 }} animate={{ y: 0, opacity: 1 }} className={cn("text-xl font-black italic uppercase italic tracking-tighter", aiFeedback.includes('Failure') ? "text-red-500" : "text-emerald-400")}>{aiFeedback}</motion.p>
                     </div>
                  </div>

                  <div className="text-center mb-32 space-y-10">
                     <p className="text-[0.8rem] font-black uppercase tracking-[1em] text-slate-800">Neural Log Sequence</p>
                     <motion.h2 
                        key={gamePrompt.question}
                        initial={{ scale: 0.9, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        className="text-[10rem] lg:text-[12rem] font-black italic tracking-[-0.05em] text-white drop-shadow-[0_0_80px_rgba(16,185,129,0.15)] leading-none uppercase"
                     >
                        {gamePrompt.question}
                     </motion.h2>
                  </div>

                  <div className="grid grid-cols-2 gap-12">
                     {gamePrompt.options.map((opt, i) => (
                       <motion.button
                         whileHover={{ scale: 1.05, y: -8 }}
                         whileTap={{ scale: 0.95 }}
                         key={i}
                         onClick={() => submitAnswer(opt)}
                         className="p-16 glass-light border border-white/5 rounded-[4rem] text-6xl font-black italic hover:bg-emerald-500 hover:text-black hover:border-emerald-500 transition-all shadow-3xl backdrop-blur-3xl"
                       >
                          {opt}
                       </motion.button>
                     ))}
                  </div>
               </motion.div>
             )}
           </AnimatePresence>

           <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
              <div className="glass p-14 rounded-[4rem] border-white/5 flex items-center justify-between group shadow-3xl">
                 <div className="space-y-4">
                    <p className="text-[0.8rem] font-black uppercase tracking-[0.6em] text-slate-600">Sync Capacity</p>
                    <p className="text-5xl font-black italic text-white tracking-tighter">{score.toLocaleString()}</p>
                 </div>
                 <BarChart3 className="w-12 h-12 text-emerald-500/20 group-hover:text-emerald-400 transition-colors" />
              </div>

              <div className="glass p-14 rounded-[4rem] border-white/5 flex flex-col justify-center space-y-8 shadow-3xl">
                 <div className="flex justify-between items-center">
                    <p className="text-[0.8rem] font-black uppercase tracking-[0.6em] text-slate-600">Pulse Consistency</p>
                    <Command className="w-6 h-6 text-emerald-500 animate-spin-slow" />
                 </div>
                 <div className="flex gap-4">
                    {[1,2,3,4,5,6,7,8,10,12].map(i => <div key={i} className={cn("h-6 w-3 rounded-full transition-all duration-700", i <= combo + 1 ? "bg-emerald-500 shadow-glow" : "bg-white/5")} />)}
                 </div>
              </div>
           </div>
        </div>
      </main>

      {/* ACHIEVEMENT TOAST */}
      <AnimatePresence>
         {showBadge && (
            <motion.div 
               initial={{ x: 300, opacity: 0 }}
               animate={{ x: 0, opacity: 1 }}
               exit={{ x: 300, opacity: 0 }}
               className="fixed bottom-12 right-12 z-[200] glass px-12 py-8 rounded-[2.5rem] border border-emerald-500/40 shadow-[0_40px_120px_rgba(0,0,0,0.8)] flex items-center gap-8"
            >
               <div className="w-16 h-16 rounded-2xl bg-emerald-500 flex items-center justify-center text-black shadow-glow">
                  <Star className="w-10 h-10 animate-spin-slow" />
               </div>
               <div>
                  <p className="text-[0.6rem] font-black uppercase text-emerald-500 tracking-[0.6em] mb-2">Protocol Unlocked</p>
                  <p className="text-3xl font-black italic text-white uppercase tracking-tighter whitespace-nowrap">{showBadge}</p>
               </div>
            </motion.div>
         )}
      </AnimatePresence>

      <style jsx global>{`
        @keyframes spin-slow { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
        .animate-spin-slow { animation: spin-slow 12s linear infinite; }
        .shadow-glow { box-shadow: 0 0 50px rgba(16, 185, 129, 0.4); }
        .shadow-3xl { box-shadow: 0 40px 100px rgba(0, 0, 0, 0.8); }
        .backdrop-blur-4xl { backdrop-filter: blur(60px); -webkit-backdrop-filter: blur(60px); }
        .text-gradient {
           background: linear-gradient(135deg, #fff 0%, #10b981 100%);
           -webkit-background-clip: text;
           -webkit-text-fill-color: transparent;
        }
      `}</style>
    </div>
  );
}
