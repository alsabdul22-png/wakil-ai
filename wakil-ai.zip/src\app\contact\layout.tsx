import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Contact Wakil AI – Get in Touch',
  description:
    'Reach out to the Wakil AI team for technical integration, enterprise partnerships, or general inquiries. We are based in Rendsburg, Germany. Email: info@wakil-rd.de.',
  openGraph: {
    title: 'Contact Wakil AI – Get in Touch',
    description:
      'Contact Wakil AI for partnerships, technical integration, or general support. Based in Rendsburg, Germany.',
    url: 'https://wakil-rd.de/contact',
  },
  alternates: {
    canonical: 'https://wakil-rd.de/contact',
  },
};

export default function ContactLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}
