'use client';

import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Send, ArrowRight, Mail, MapPin, Globe, Zap, MessageSquare, ShieldCheck } from 'lucide-react';

export default function WakilContact() {
  const [sent, setSent] = useState(false);

  return (
    <div className="flex flex-col min-h-[80vh] px-6 lg:px-20 py-10 lg:py-20 relative text-slate-200">
      <div className="max-w-7xl mx-auto w-full">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 lg:gap-32 items-center">
          
          {/* LEFT SIDE: INFO */}
          <motion.div 
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-12"
          >
            <div className="space-y-6">
              <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full glass border border-emerald-500/20 text-emerald-400 text-[0.6rem] font-black uppercase tracking-[0.3em]">
                <Globe className="w-3 h-3" /> Global Transmission
              </div>
              <h1 className="text-5xl lg:text-7xl font-black italic tracking-tighter text-white leading-[1.1]">
                Initialize <span className="text-emerald-400">Connection</span>.
              </h1>
              <p className="text-slate-400 font-medium lg:text-lg max-w-lg">
                Whether you're looking for technical integration, enterprise partnership, or just want to say hello, our neural gates are open.
              </p>
            </div>

            <div className="grid grid-cols-1 gap-6">
              {[
                { label: "Secure Email", value: "info@wakil-rd.de", icon: Mail, color: "text-emerald-400" },
                { label: "Neural HQ", value: "Rendsburg, Germany", icon: MapPin, color: "text-blue-400" },
                { label: "Uptime Status", value: "99.9% Node Integrity", icon: ShieldCheck, color: "text-purple-400" },
              ].map((item) => (
                <div key={item.label} className="flex items-center gap-6 p-6 glass rounded-3xl border border-white/5 group hover:border-emerald-500/20 transition-all">
                  <div className="w-14 h-14 rounded-2xl glass border border-white/10 flex items-center justify-center group-hover:scale-110 transition-transform">
                    <item.icon className={cn("w-6 h-6", item.color)} />
                  </div>
                  <div>
                    <h3 className="text-[0.6rem] font-black uppercase tracking-widest text-slate-500 mb-1">{item.label}</h3>
                    <p className="text-lg font-black text-white italic tracking-tight">{item.value}</p>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>

          {/* RIGHT SIDE: FORM */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="relative"
          >
            <div className="absolute -inset-1 bg-gradient-to-br from-emerald-500/20 to-teal-500/20 rounded-[3rem] blur-2xl opacity-50" />
            <div className="relative glass border border-white/10 rounded-[3rem] p-8 lg:p-12 shadow-2xl overflow-hidden group">
              <div className="absolute -right-20 -top-20 w-64 h-64 bg-emerald-500/10 rounded-full blur-[100px]" />
              
              <div className="mb-10 text-center lg:text-left relative z-10">
                <h2 className="text-2xl font-black italic tracking-tighter text-white uppercase mb-2">Secure Inquiry</h2>
                <p className="text-xs font-bold text-slate-500 uppercase tracking-widest">Encrypted Transmission Protocols Active</p>
              </div>

              <form className="space-y-6 relative z-10" onSubmit={(e) => { e.preventDefault(); setSent(true); }}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-[0.6rem] font-black uppercase tracking-[0.2em] text-slate-400 ml-2">Identifier</label>
                    <input type="text" placeholder="Your Name" className="w-full bg-slate-900/50 border border-white/10 rounded-2xl px-6 py-4 outline-none focus:border-emerald-500/50 transition-all text-sm font-medium focus:bg-emerald-500/5" required />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[0.6rem] font-black uppercase tracking-[0.2em] text-slate-400 ml-2">Neural Address</label>
                    <input type="email" placeholder="email@provider.com" className="w-full bg-slate-900/50 border border-white/10 rounded-2xl px-6 py-4 outline-none focus:border-emerald-500/50 transition-all text-sm font-medium focus:bg-emerald-500/5" required />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-[0.6rem] font-black uppercase tracking-[0.2em] text-slate-400 ml-2">Signal Data</label>
                  <textarea placeholder="Describe the mission..." className="w-full bg-slate-900/50 border border-white/10 rounded-2xl px-6 py-6 outline-none focus:border-emerald-500/50 transition-all text-sm font-medium h-40 resize-none focus:bg-emerald-500/5 shadow-inner" required />
                </div>

                <button 
                  type="submit" 
                  disabled={sent} 
                  className={cn(
                    "w-full py-6 rounded-[2rem] text-sm font-black uppercase tracking-[0.3em] flex items-center justify-center gap-4 transition-all shadow-2xl shadow-emerald-500/20",
                    sent ? "bg-slate-800 text-emerald-400 cursor-default" : "bg-emerald-500 text-black hover:bg-emerald-400 active:scale-95"
                  )}
                >
                  {sent ? (
                    <>Signal Intercepted <ShieldCheck className="w-5 h-5" /></>
                  ) : (
                    <>Launch Transmission <Send className="w-5 h-5" /></>
                  )}
                </button>
                
                {sent && (
                  <motion.p 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="text-center text-[0.65rem] text-emerald-500 font-black tracking-[0.2em] uppercase animate-pulse"
                  >
                    Wakil AI is processing your request. <br /> Standing by for response.
                  </motion.p>
                )}
              </form>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}

function cn(...inputs: any[]) {
  return inputs.filter(Boolean).join(' ');
}
