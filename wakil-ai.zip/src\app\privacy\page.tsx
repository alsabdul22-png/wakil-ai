'use client';

import React from 'react';
import { motion } from 'framer-motion';
import { Shield, Lock, Eye, FileText, Zap, ArrowRight } from 'lucide-react';
import Link from 'next/link';

export default function PrivacyPolicy() {
  return (
    <div className="flex flex-col min-h-screen px-6 lg:px-20 py-32 relative text-slate-200 overflow-hidden">
      {/* Dynamic Background */}
      <div className="fixed inset-0 pointer-events-none z-0">
        <div className="absolute top-0 left-[-10%] w-[40%] h-[40%] bg-emerald-500/5 blur-[120px] rounded-full animate-pulse" />
        <div className="absolute bottom-0 right-[-10%] w-[50%] h-[50%] bg-blue-500/5 blur-[120px] rounded-full animate-pulse" style={{ animationDelay: '2s' }} />
      </div>

      <div className="max-w-4xl mx-auto w-full relative z-10">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-20"
        >
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full glass border border-emerald-500/20 text-emerald-400 text-[0.6rem] font-black uppercase tracking-[0.3em] mb-6">
            <Lock className="w-3 h-3 fill-emerald-400" /> Security Protocol
          </div>
          <h1 className="text-5xl lg:text-7xl font-black italic tracking-tighter text-white leading-tight uppercase">
            Privacy <span className="text-emerald-400">Policy</span>.
          </h1>
          <p className="text-slate-500 mt-6 font-medium uppercase tracking-[0.2em] text-[0.7rem]">
            Last Updated: March 28, 2026 • Node V2.4
          </p>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="glass p-10 lg:p-20 rounded-[3rem] border border-white/5 space-y-12 backdrop-blur-3xl shadow-2xl"
        >
          <section className="space-y-6">
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/10 flex items-center justify-center border border-emerald-500/20">
                <Eye className="w-5 h-5 text-emerald-400" />
              </div>
              <h2 className="text-2xl font-black italic uppercase text-white tracking-tight">01. Data Collection</h2>
            </div>
            <p className="text-slate-400 leading-relaxed font-medium">
              Wakil AI respects the sanctity of your neural data. We only collect information essential for the execution of our autonomous services, including session metadata, interaction history with the Barada Neural Network, and basic account identifiers. We do not engage in the commodification of user data.
            </p>
          </section>

          <section className="space-y-6">
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 rounded-xl bg-blue-500/10 flex items-center justify-center border border-blue-500/20">
                <Shield className="w-5 h-5 text-blue-400" />
              </div>
              <h2 className="text-2xl font-black italic uppercase text-white tracking-tight">02. Neural Security</h2>
            </div>
            <p className="text-slate-400 leading-relaxed font-medium">
              All transmissions between your local node and the Wakil AI infrastructure are end-to-end encrypted using advanced cryptographic protocols. Your data is stored on decentralized secure servers, ensuring that even in the event of a node failure, your information remains protected and private.
            </p>
          </section>

          <section className="space-y-6">
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 rounded-xl bg-purple-500/10 flex items-center justify-center border border-purple-500/20">
                <FileText className="w-5 h-5 text-purple-400" />
              </div>
              <h2 className="text-2xl font-black italic uppercase text-white tracking-tight">03. User Rights</h2>
            </div>
            <p className="text-slate-400 leading-relaxed font-medium">
              As a participant in the Wakil ecosystem, you retain full sovereignty over your data. You may request the termination of your account and the complete erasure of your interaction logs at any time. We believe transparency is the foundation of digital intelligence.
            </p>
          </section>

          <div className="pt-10 border-t border-white/5">
             <p className="text-xs text-slate-500 text-center italic font-medium">
                For detailed security audits or specific data inquiries, please contact the governance node at <span className="text-emerald-500">privacy@wakil-rd.de</span>
             </p>
          </div>
        </motion.div>

        <div className="mt-20 text-center">
          <Link href="/" className="inline-flex items-center gap-3 text-[0.65rem] font-bold uppercase tracking-[0.4em] text-slate-500 hover:text-emerald-500 transition-all">
            Return to Core <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </div>
    </div>
  );
}
