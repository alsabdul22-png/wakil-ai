import NextAuth from "next-auth";
import Credentials from "next-auth/providers/credentials";
import bcrypt from "bcryptjs";
import db from "@/lib/db";

const authOptions = {
  providers: [
    Credentials({
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Password", type: "password" },
      },
      async authorize(credentials) {
        if (!credentials?.email || !credentials?.password) return null;

        try {
          const result = await db.execute({
            sql: 'SELECT * FROM users WHERE email = ?',
            args: [credentials.email as string]
          });

          const user: any = result.rows[0];

          if (!user) return null;

          const isPasswordCorrect = await bcrypt.compare(
            credentials.password as string,
            user.password as string
          );

          if (!isPasswordCorrect) return null;

          return {
            id: user.id as string,
            name: user.name as string,
            email: user.email as string,
          };
        } catch (error) {
          console.error("Auth Error:", error);
          return null;
        }
      },
    }),
  ],
  pages: {
    signIn: "/login",
  },
  callbacks: {
    async jwt({ token, user }: any) {
      if (user) {
        token.id = user.id;
      }
      return token;
    },
    async session({ session, token }: any) {
      if (session.user) {
        session.user.id = token.id;
      }
      return session;
    },
  },
  secret: process.env.NEXTAUTH_SECRET || "futuristic-secret-key-wakil-ai",
};

export default NextAuth(authOptions);
export { authOptions };
