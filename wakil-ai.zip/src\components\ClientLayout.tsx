'use client';

import Link from 'next/link';
import JawadAI from './JawadAI';
import { usePathname } from 'next/navigation';
import { motion, AnimatePresence } from 'framer-motion';
import { Command, Menu, X, ArrowRight } from 'lucide-react';
import { useState } from 'react';

function Navigation() {
  const pathname = usePathname();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const isChat = pathname?.startsWith('/chat');
  const isExp = pathname?.startsWith('/experience');

  if (isChat || isExp) return null;

  return (
    <AnimatePresence>
      <motion.nav
        initial={{ y: -100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: -100, opacity: 0 }}
        className="fixed top-6 left-1/2 -translate-x-1/2 z-[100] w-[calc(100%-2rem)] max-w-6xl glass rounded-full border border-white/10 py-3 px-8 flex items-center justify-between backdrop-blur-3xl shadow-xl"
      >
        <Link href="/" className="flex items-center gap-4 group">
          <div className="relative w-10 h-10 flex items-center justify-center">
            <motion.div 
               animate={{ rotate: 360 }}
               transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
               className="absolute inset-0 border-2 border-emerald-500/20 rounded-xl"
            />
            <img
              src="/logo.png"
              alt="Wakil AI"
              className="w-full h-full object-contain mix-blend-screen drop-shadow-[0_0_10px_#10b981] group-hover:scale-110 transition-transform"
            />
          </div>
          <div className="hidden sm:block">
            <span className="block text-lg font-black italic tracking-tight text-white uppercase leading-none">
              Wakil <span className="text-emerald-500">Node</span>
            </span>
          </div>
        </Link>

        {/* Desktop Links */}
        <div className="hidden lg:flex items-center gap-10">
          {['News', 'Features', 'Experience', 'About'].map((item) => (
            <Link
              key={item}
              href={
                item === 'News' ? '/#news' :
                item === 'Features' ? '/#features' :
                item === 'Experience' ? '/experience' :
                `/${item.toLowerCase()}`
              }
              className="text-[0.6rem] font-bold uppercase tracking-widest text-slate-400 hover:text-emerald-500 transition-all relative"
            >
              {item}
            </Link>
          ))}
        </div>

        <div className="flex items-center gap-4">
           <button onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} className="lg:hidden p-2.5 glass-light border border-white/10 rounded-xl text-white">
              <Menu className="w-5 h-5" />
           </button>
           <Link
             href="/chat"
             className="hidden sm:flex items-center gap-4 px-8 py-2.5 bg-emerald-500 text-black rounded-full text-[0.65rem] font-bold uppercase tracking-wider shadow-lg hover:bg-white hover:scale-105 transition-all flex items-center justify-center"
           >
             Connect Now
           </Link>
        </div>

        {/* Mobile Menu */}
        <AnimatePresence>
           {isMobileMenuOpen && (
              <motion.div 
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="absolute top-[calc(100%+1rem)] left-0 right-0 glass p-10 rounded-[3rem] border border-white/10 shadow-[0_50px_100px_rgba(0,0,0,0.95)] flex flex-col gap-8 lg:hidden bg-slate-900/90 backdrop-blur-4xl"
              >
                  {['News', 'Features', 'Experience', 'About'].map((item) => (
                    <Link
                      key={item}
                      onClick={() => setIsMobileMenuOpen(false)}
                      href={
                        item === 'News' ? '/#news' :
                        item === 'Features' ? '/#features' :
                        item === 'Experience' ? '/experience' :
                        `/${item.toLowerCase()}`
                      }
                      className="text-[0.7rem] font-black uppercase tracking-[0.5em] text-slate-400 p-4 hover:bg-white/5 rounded-2xl flex items-center justify-between group"
                    >
                      {item}
                      <ArrowRight className="w-5 h-5 opacity-0 group-hover:opacity-100 transition-all" />
                    </Link>
                  ))}
                  <Link
                    href="/chat"
                    onClick={() => setIsMobileMenuOpen(false)}
                    className="w-full flex items-center justify-center gap-4 px-10 py-6 bg-emerald-500 text-black rounded-3xl text-[0.8rem] font-black uppercase tracking-[0.4em] shadow-2xl"
                  >
                    Launch Core
                  </Link>
              </motion.div>
           )}
        </AnimatePresence>
      </motion.nav>
    </AnimatePresence>
  );
}

export default function ClientLayout({ children }: { children: React.ReactNode }) {
  return (
    <>
      <Navigation />
      <main className="min-h-screen relative z-10 transition-opacity">
        {children}
      </main>
      <JawadAI />
      
      <style jsx global>{`
        .backdrop-blur-4xl {
           backdrop-filter: blur(60px);
           -webkit-backdrop-filter: blur(60px);
        }
      `}</style>
    </>
  );
}
