'use client';

import React from 'react';
import { motion } from 'framer-motion';
import { Gavel, Globe, Cpu, Zap, ArrowRight, ShieldCheck, FileKey, Scale } from 'lucide-react';
import Link from 'next/link';

export default function TermsOfUse() {
  return (
    <div className="flex flex-col min-h-screen px-6 lg:px-20 py-32 relative text-slate-200 overflow-hidden font-inter">
      {/* Dynamic Background */}
      <div className="fixed inset-0 pointer-events-none z-0">
        <div className="absolute top-0 right-[-10%] w-[40%] h-[40%] bg-blue-500/5 blur-[120px] rounded-full animate-pulse" />
        <div className="absolute bottom-0 left-[-10%] w-[50%] h-[50%] bg-emerald-500/5 blur-[120px] rounded-full animate-pulse" style={{ animationDelay: '2s' }} />
      </div>

      <div className="max-w-4xl mx-auto w-full relative z-10">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-20"
        >
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full glass border border-blue-500/20 text-blue-400 text-[0.6rem] font-black uppercase tracking-[0.3em] mb-6">
            <Scale className="w-3 h-3 fill-blue-400" /> Legal Governance
          </div>
          <h1 className="text-5xl lg:text-7xl font-black italic tracking-tighter text-white leading-tight uppercase">
            Terms of <span className="text-emerald-400">Use</span>.
          </h1>
          <p className="text-slate-500 mt-6 font-medium uppercase tracking-[0.2em] text-[0.7rem]">
            Last Updated: March 28, 2026 • Node V2.4
          </p>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="glass p-10 lg:p-20 rounded-[3rem] border border-white/5 space-y-12 backdrop-blur-3xl shadow-2xl"
        >
          <section className="space-y-6">
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 rounded-xl bg-blue-500/10 flex items-center justify-center border border-blue-500/20">
                <Gavel className="w-5 h-5 text-blue-400" />
              </div>
              <h2 className="text-2xl font-black italic uppercase text-white tracking-tight">01. Acceptance of Terms</h2>
            </div>
            <p className="text-slate-400 leading-relaxed font-medium">
              By accessing the Wakil AI platform and establishing a neural transmission link, you agree to be bound by these Terms of Use and all applicable regional laws. Our services are designed for autonomous assistance and professional exploration. Any misuse for illicit activities is strictly prohibited and will result in node termination.
            </p>
          </section>

          <section className="space-y-6">
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/10 flex items-center justify-center border border-emerald-500/20">
                <Cpu className="w-5 h-5 text-emerald-400" />
              </div>
              <h2 className="text-2xl font-black italic uppercase text-white tracking-tight">02. Neural License</h2>
            </div>
            <p className="text-slate-400 leading-relaxed font-medium">
              Wakil AI grants you a personal, non-transferable, and non-exclusive license to utilize our autonomous intelligence tools. This license is provided "as is" with no guarantees of 100% computational accuracy, although our systems are calibrated for high-fidelity reasoning via the Barada core.
            </p>
          </section>

          <section className="space-y-6">
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 rounded-xl bg-purple-500/10 flex items-center justify-center border border-purple-500/20">
                <ShieldCheck className="w-5 h-5 text-purple-400" />
              </div>
              <h2 className="text-2xl font-black italic uppercase text-white tracking-tight">03. Content Responsibility</h2>
            </div>
            <p className="text-slate-400 leading-relaxed font-medium">
              You are solely responsible for the content generated via your unique node and how it is applied in third-party environments. Wakil AI and its chief architect, Abdulrahman Alshouly, assume no liability for external decisions made using our intellectual frameworks.
            </p>
          </section>

          <div className="pt-10 border-t border-white/5">
             <p className="text-xs text-slate-500 text-center italic font-medium leading-relaxed">
                We reserve the right to modify these terms as the Wakil architecture evolves. <br /> Continued use of our nodes constitutes acceptance of updated legal frameworks.
             </p>
          </div>
        </motion.div>

        <div className="mt-20 text-center">
          <Link href="/" className="inline-flex items-center gap-3 text-[0.65rem] font-bold uppercase tracking-[0.4em] text-slate-500 hover:text-emerald-500 transition-all">
            Return to Core <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </div>
    </div>
  );
}
