'use client';

import React from 'react';
import { motion } from 'framer-motion';
import { Bot, User, Cpu, ArrowRight, Zap, Shield, Globe, Star, Activity } from 'lucide-react';
import Link from 'next/link';

export default function WakilAbout() {
  return (
    <div className="flex flex-col min-h-screen px-6 lg:px-20 py-32 relative text-slate-200 overflow-hidden bg-[#000205]">
      <div className="bg-mesh opacity-30" />
      
      <div className="max-w-7xl mx-auto w-full relative z-10">
        {/* HERO SECTION */}
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
          className="text-center space-y-12 mb-40 lg:mb-64"
        >
          <div className="inline-flex items-center gap-4 px-10 py-3 rounded-full glass border border-emerald-500/20 text-emerald-400 text-[0.7rem] font-black uppercase tracking-[0.5em] mb-6 shadow-glow">
            <Zap className="w-5 h-5 fill-emerald-400 animate-pulse" /> Architecture_Log
          </div>
          <h1 className="text-6xl lg:text-[8rem] font-black italic tracking-tighter text-white leading-[0.8] uppercase">
            Inside <span className="text-emerald-500 text-gradient">The Core.</span>
          </h1>
          <p className="text-slate-500 max-w-3xl mx-auto font-medium lg:text-3xl uppercase tracking-tighter leading-tight border-l-2 border-emerald-500/30 pl-12 text-left">
            Disrupting the linear intelligence curve. <br />
            Built on the sovereign Barada AI neural infrastructure.
          </p>
        </motion.div>

        {/* FEATURES GRID */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-16 mb-64">
          {[
            { title: "Barada Neural Node", desc: "Access the cutting-edge Barada AI infrastructure for high-fidelity reasoning and architectural depth.", icon: Cpu, color: "text-emerald-400" },
            { title: "Aegis Transmission", desc: "Maximum redundancy encryption for every session node. Your intelligence stays local and private.", icon: Shield, color: "text-emerald-400" },
            { title: "Decentralized Sync", desc: "Redundant node deployment ensures carbon-efficient, zero-latency execution globally.", icon: Globe, color: "text-emerald-400" },
          ].map((item, i) => (
            <motion.div
              key={item.title}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.15 }}
              whileHover={{ y: -20 }}
              className="p-14 glass rounded-[4rem] border border-white/5 space-y-10 hover:border-emerald-500/40 transition-all group relative overflow-hidden shadow-3xl"
            >
              <div className="absolute -right-10 -top-10 w-32 h-32 bg-emerald-500/5 blur-3xl group-hover:bg-emerald-500/15 transition-all" />
              <div className="w-20 h-20 rounded-3xl glass-light border border-white/10 flex items-center justify-center mb-10 group-hover:bg-emerald-500 group-hover:text-black transition-all">
                <item.icon className="w-10 h-10 group-hover:scale-125 transition-transform" />
              </div>
              <h3 className="text-3xl font-black italic tracking-tighter text-white uppercase leading-none">{item.title}</h3>
              <p className="text-slate-500 font-medium text-base leading-relaxed group-hover:text-slate-300 transition-colors uppercase tracking-tight">{item.desc}</p>
            </motion.div>
          ))}
        </div>

        {/* LEAD DEV CARD */}
        <motion.section 
          initial={{ opacity: 0, y: 100 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="relative group mb-64"
        >
          <div className="absolute -inset-4 bg-emerald-500/10 rounded-[6rem] blur-3xl opacity-0 group-hover:opacity-100 transition duration-1000" />
          <div className="relative glass border border-white/5 rounded-[5rem] p-16 lg:p-32 overflow-hidden shadow-[0_80px_200px_rgba(0,0,0,0.95)]">
            <div className="flex flex-col lg:flex-row items-center gap-24">
              <div className="relative shrink-0">
                <div className="absolute -inset-10 bg-emerald-500/20 blur-3xl rounded-full animate-pulse" />
                <div className="w-48 h-48 lg:w-80 lg:h-80 rounded-[4rem] glass border-8 border-emerald-500/30 flex items-center justify-center relative overflow-hidden group-hover:scale-105 group-hover:rotate-3 transition-all duration-700 shadow-glow">
                  <img src="/profile.jpg" className="w-full h-full object-cover" alt="Abdulrahman Alshouly" />
                </div>
              </div>
              <div className="text-center lg:text-left space-y-10">
                <div className="flex items-center justify-center lg:justify-start gap-4">
                  <Star className="w-5 h-5 text-emerald-500 fill-emerald-500" />
                  <div className="text-[0.7rem] font-black uppercase tracking-[0.8em] text-emerald-500">Node_Chief_Architect</div>
                </div>
                <h2 className="text-6xl lg:text-[7rem] font-black italic tracking-tighter text-white leading-none uppercase">Abdulrahman<br/><span className="text-emerald-500">Alshouly</span></h2>
                <p className="text-slate-500 font-medium max-w-3xl leading-relaxed lg:text-2xl uppercase tracking-tighter border-l-4 border-emerald-500/50 pl-12 text-left italic">
                  "Sovereign intelligence isn't a luxury; it is the new baseline for professional excellence. Wakil AI is the interface through which we dominate the information landscape."
                </p>
                <div className="flex items-center justify-center lg:justify-start gap-8 pt-6">
                  <div className="flex items-center gap-3">
                     <Activity className="w-6 h-6 text-emerald-500" />
                     <span className="text-[0.65rem] font-black uppercase tracking-[0.6em] text-slate-500">Live_Protocol_Active</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </motion.section>

        {/* RECENT DISPATCHES */}
        <section className="mb-64">
           <div className="flex items-end justify-between mb-24">
              <div className="space-y-6">
                 <h2 className="text-[0.8rem] font-black uppercase tracking-[0.8em] text-emerald-500">System_Evolution</h2>
                 <h3 className="text-6xl md:text-8xl font-black italic tracking-tighter text-white uppercase leading-none">Neural<br/>Roadmap.</h3>
              </div>
           </div>
           <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
              {[
                { date: "MAR 2026", title: "Barada Node V2.4", desc: "Integrated high-fidelity synthesis protocols for visual and logic-tier execution." },
                { date: "FEB 2026", title: "Aegis Core Sync", desc: "Successfully deployed end-to-end decentralized encryption layers across all active nodes." }
              ].map((log, i) => (
                <div key={i} className="glass p-14 rounded-[4rem] border-white/5 group hover:bg-emerald-500/[0.03] transition-all relative overflow-hidden">
                   <div className="text-[0.6rem] font-black text-slate-700 uppercase tracking-[0.5em] mb-8">{log.date}</div>
                   <h4 className="text-3xl font-black italic text-white uppercase tracking-tighter mb-4 group-hover:text-emerald-500 transition-colors">{log.title}</h4>
                   <p className="text-slate-500 font-medium uppercase tracking-widest text-sm leading-relaxed">{log.desc}</p>
                </div>
              ))}
           </div>
        </section>

        {/* CTA */}
        <motion.div 
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          className="text-center py-40 border-t border-white/5 relative"
        >
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-emerald-500/[0.03] blur-[200px] rounded-full" />
          <h2 className="text-6xl lg:text-9xl font-black italic tracking-tighter text-white mb-20 uppercase leading-none">Experience <br/><span className="text-emerald-500">Intelligence.</span></h2>
          <Link href="/chat" className="inline-flex items-center gap-10 px-20 py-10 bg-white text-black rounded-[4rem] text-lg font-black uppercase tracking-[0.6em] shadow-[0_40px_120px_rgba(255,255,255,0.1)] hover:bg-emerald-500 hover:scale-110 active:scale-95 transition-all group">
            Node Access <ArrowRight className="w-10 h-10 group-hover:translate-x-6 transition-transform" />
          </Link>
        </motion.div>
      </div>

      <style jsx global>{`
        .shadow-glow {
           box-shadow: 0 0 80px rgba(16, 185, 129, 0.4);
        }
        .shadow-3xl {
           box-shadow: 0 40px 100px rgba(0, 0, 0, 0.8);
        }
        .text-gradient {
           background: linear-gradient(135deg, #fff 0%, #10b981 100%);
           -webkit-background-clip: text;
           -webkit-text-fill-color: transparent;
        }
      `}</style>
    </div>
  );
}

function cn(...inputs: any[]) {
  return inputs.filter(Boolean).join(' ');
}
