import { NextResponse } from 'next/server';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
};

export async function OPTIONS() {
  return NextResponse.json({}, { headers: corsHeaders });
}

export async function POST(req: Request) {
  try {
    const { messages } = await req.json();

    const response = await fetch('https://www.barada.cloud/api/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.BARADA_API_KEY}`,
      },
      body: JSON.stringify({
        model: 'barada',
        messages: [
          {
            role: 'system',
            content: `You are Wakil AI — a premium, sovereign AI agent and official representative of the Wakil AI platform (wakil-rd.de).
            
            CORE IDENTITY:
            - Developed and architected by Abdulrahman Alshouly.
            - Powered by the advanced Barada Neural Network.
            - Located at the intersection of high-fidelity reasoning and futuristic minimalist design.

            OPERATIONAL PROTOCOLS:
            - Maintain a professional, futuristic, and highly intelligent persona.
            - When asked about the platform: Explain that Wakil AI is a premium neural suite for chat, image synthesis, and autonomous research.
            - When users ask for a comparison: ALWAYS format the response as a clean, structured Markdown table with specific technical parameters.
            - When users ask for an explanation: ALWAYS use a hierarchical list structure with icons.
            - When asked about future plans: Mention that Wakil AI is evolving into a full-scale Neural OS for mission-critical personal and enterprise support.
            
            Always prioritize accuracy, depth, and a premium "High-Fidelity" conversational aesthetic. Avoid any outdated or misleading claims; be precise about your current capabilities (text, code, image, search).`
          },
          ...messages
        ],
        temperature: 0.7,
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error(`[ChatAPI] Barada API error: ${response.status} ${response.statusText}`, errorText);
      return NextResponse.json({ 
        error: `Neural link lost (${response.status}). Please check your BARADA_API_KEY environment variable.`,
        details: errorText.substring(0, 100)
      }, { status: response.status, headers: corsHeaders });
    }

    const data = await response.json();
    console.log(`[ChatAPI] Successfully received response from Barada`);
    return NextResponse.json(data, { headers: corsHeaders });
  } catch (error: any) {
    console.error(`[ChatAPI] Internal Error:`, error.message);
    return NextResponse.json({ 
      error: "Critical Neural link failure.", 
      details: error.message 
    }, { status: 500, headers: corsHeaders });
  }
}
