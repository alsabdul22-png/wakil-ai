VF'use client';

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Bot, User, Image as ImageIcon, MessageSquare, Send, Sparkles, Wand2, Loader2,
  Search, Code, LayoutDashboard, History, Settings, LogOut, ChevronLeft,
  Plus, MoreVertical, Copy, RotateCcw, ArrowDown, Command, Search as SearchIcon,
  X, Moon, Sun, Monitor, Type, Zap, CheckCircle2, Fingerprint, Activity
} from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import Link from 'next/link';

// --- HELPERS ---
function cn(...inputs: any[]) {
  return inputs.filter(Boolean).join(' ');
}

type Message = {
  role: 'user' | 'assistant';
  content: string;
  type?: 'text' | 'image';
  tool?: 'chat' | 'image' | 'search' | 'code';
  status?: 'loading' | 'done' | 'error';
};

const ImageMessage = ({ src }: { src: string }) => (
  <div className="rounded-[2.5rem] overflow-hidden border border-white/5 shadow-3xl group relative">
    <div className="absolute inset-0 bg-emerald-500/10 opacity-0 group-hover:opacity-100 transition-opacity duration-700 pointer-events-none" />
    <img src={src} alt="AI Generated" className="max-w-full h-auto object-cover hover:scale-105 transition-transform duration-1000" />
    <div className="absolute top-6 right-6 p-4 glass rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity border border-emerald-500/40">
      <Sparkles className="w-6 h-6 text-emerald-500" />
    </div>
  </div>
);

export default function WakilChat() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [activeTool, setActiveTool] = useState<'chat' | 'image' | 'search' | 'code'>('chat');
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [toasts, setToasts] = useState<{ id: number; msg: string }[]>([]);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isCommandOpen, setIsCommandOpen] = useState(false);
  const [showScrollBtn, setShowScrollBtn] = useState(false);
  const [hasStarted, setHasStarted] = useState(false);

  const scrollRef = useRef<HTMLDivElement>(null);
  const chatContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!hasStarted) {
      setHasStarted(true);
    }
  }, [hasStarted]);

  const addToast = (msg: string) => {
    const id = Date.now();
    setToasts(p => [...p, { id, msg }]);
    setTimeout(() => setToasts(p => p.filter(t => t.id !== id)), 3000);
  };

  const scrollToBottom = () => {
    scrollRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSuggestion = (text: string) => {
    setInput(text);
    setTimeout(() => {
      const sendBtn = document.getElementById('send-button');
      sendBtn?.click();
    }, 100);
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    addToast("Copied to system buffer");
  };

  useEffect(() => {
    const handleScroll = () => {
      if (!chatContainerRef.current) return;
      const { scrollTop, scrollHeight, clientHeight } = chatContainerRef.current;
      setShowScrollBtn(scrollHeight - scrollTop - clientHeight > 300);
    };
    chatContainerRef.current?.addEventListener('scroll', handleScroll);
    return () => chatContainerRef.current?.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        setIsCommandOpen(prev => !prev);
      }
      if (e.key === 'Escape') {
        setIsCommandOpen(false);
        setIsSettingsOpen(false);
      }
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, []);

  const handleSend = async () => {
    const messageToSend = input.trim();
    if (!messageToSend || isLoading) return;

    setMessages(p => [...p, { role: 'user', content: messageToSend, tool: activeTool }]);
    setInput('');
    setIsLoading(true);

    if (activeTool === 'image') {
      const imgMsg: Message = { role: 'assistant', content: "Neural rendering in progress...", type: 'image', status: 'loading', tool: 'image' };
      setMessages(p => [...p, imgMsg]);

      try {
        const res = await fetch('/api/images', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ prompt: messageToSend })
        });

        const data = await res.json();

        if (data.data?.[0]?.b64_json) {
          setMessages(p => {
            const updated = [...p];
            const last = updated[updated.length - 1];
            last.content = `data:image/png;base64,${data.data[0].b64_json}`;
            last.status = 'done';
            return updated;
          });
        } else {
          throw new Error(data.error?.message || "Synthesis failure.");
        }
      } catch (e: any) {
        setMessages(p => {
          const updated = [...p];
          const last = updated[updated.length - 1];
          last.content = `Rendering failed: ${e.message}`;
          last.status = 'error';
          return updated;
        });
      } finally {
        setIsLoading(false);
      }
      return;
    }

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: messages.map(m => ({ role: m.role, content: m.content })).concat([{ role: 'user', content: messageToSend }]),
          mode: activeTool
        })
      });
      const data = await res.json();

      let aiContent = "Neural link established but transmission was empty.";
      if (data.error) {
        aiContent = `System Error: ${data.error}`;
      } else if (data.choices?.[0]?.message?.content) {
        aiContent = data.choices[0].message.content;
      }

      setMessages(p => [...p, { role: 'assistant', content: aiContent, tool: activeTool }]);
    } catch (e: any) {
      setMessages(p => [...p, { role: 'assistant', content: `Transmission failed: ${e.message}`, tool: activeTool }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex h-screen bg-[#000205] overflow-hidden selection:bg-emerald-500/40 font-inter">
      <div className="bg-mesh opacity-20" />

      {/* --- SIDEBAR --- */}
      <motion.aside
        initial={false}
        animate={{ width: sidebarOpen ? '320px' : '0px', opacity: sidebarOpen ? 1 : 0 }}
        className="relative z-30 border-r border-white/5 glass flex flex-col overflow-hidden backdrop-blur-4xl shadow-3xl"
      >
        <div className="p-6 flex items-center gap-4 border-b border-white/5 bg-black/20">
          <div className="flex items-center gap-2">
            <motion.img
              animate={{ rotate: 360 }}
              transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
              src="/logo.png" className="w-8 h-8 object-contain mix-blend-screen drop-shadow-[0_0_10px_#10b981]"
            />
          </div>
          <div>
            <h2 className="text-sm font-black italic tracking-tighter text-white uppercase">WAKIL</h2>
            <div className="flex items-center gap-2">
              <div className="w-1 h-1 rounded-full bg-emerald-500 animate-pulse" />
              <p className="text-[0.45rem] font-black tracking-[0.4em] text-emerald-500/80 uppercase">Node_4F2A</p>
            </div>
          </div>
        </div>

        <div className="p-6">
          <button
            onClick={() => { setMessages([]); addToast("Session Purged. Initializing new Link."); }}
            className="w-full flex items-center justify-between px-6 py-4 bg-emerald-500 text-black rounded-2xl hover:bg-white transition-all group shadow-lg"
          >
            <div className="flex items-center gap-3">
              <Plus className="w-5 h-5 group-hover:rotate-90 transition-transform" />
              <span className="text-[0.7rem] font-bold uppercase tracking-wider">New Link</span>
            </div>
            <ChevronLeft className="w-3 h-3 opacity-40 shrink-0" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto custom-scrollbar p-8 space-y-4">
          <div className="flex items-center justify-between px-6 py-4 bg-emerald-500/10 border border-emerald-500/20 rounded-2xl text-white group cursor-pointer hover:bg-emerald-500/20 transition-all">
            <div className="flex items-center gap-4">
              <History className="w-5 h-5 text-emerald-400" />
              <span className="text-[0.7rem] font-black uppercase tracking-[0.2em] truncate italic text-emerald-400">Live_Transmission</span>
            </div>
            <Activity className="w-4 h-4 text-emerald-500 animate-pulse" />
          </div>
          {[1, 2, 3].map(i => (
            <div key={i} className="flex items-center gap-4 px-6 py-4 rounded-2xl text-slate-500 hover:bg-white/5 hover:text-slate-300 transition-all cursor-pointer group border border-transparent hover:border-white/5">
              <History className="w-5 h-5 group-hover:text-emerald-400" />
              <span className="text-[0.7rem] font-black uppercase tracking-[0.2em] truncate italic">NODE_LOG_B8{i}4...</span>
            </div>
          ))}
        </div>

        <div className="p-8 border-t border-white/5 grid grid-cols-2 gap-4">
          <button onClick={() => setIsSettingsOpen(true)} className="flex items-center justify-center gap-3 py-4 glass-light rounded-2xl text-slate-500 hover:text-white hover:border-emerald-500/30 transition-all">
            <Settings className="w-5 h-5" />
          </button>
          <Link href="/" className="flex items-center justify-center gap-3 py-4 glass-light rounded-2xl text-red-500/40 hover:text-red-500 hover:bg-red-500/5 hover:border-red-500/20 transition-all">
            <LogOut className="w-5 h-5" />
          </Link>
        </div>
      </motion.aside>

      {/* --- MAIN AREA --- */}
      <main className="flex-1 flex flex-col relative bg-[#000205]">
        <header className="h-20 flex items-center justify-between px-8 border-b border-white/5 relative z-20 backdrop-blur-4xl shadow-md bg-black/10">
          <div className="flex items-center gap-6">
            <button onClick={() => setSidebarOpen(!sidebarOpen)} className="p-3 hover:bg-white/5 rounded-xl transition-all border border-white/5 glass-light group">
              <ChevronLeft className={cn("w-5 h-5 text-slate-500 transition-transform group-hover:text-white", !sidebarOpen && "rotate-180")} />
            </button>
            <div className="flex items-center gap-6">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl glass-light flex items-center justify-center p-1.5 border border-emerald-500/20 group hover:border-emerald-500/50 transition-all">
                  <img src="/logo.png" className="w-full h-full object-contain mix-blend-screen" />
                </div>
                <div>
                  <p className="text-[0.45rem] font-black uppercase tracking-[0.4em] text-emerald-500">Node_Active</p>
                  <p className="text-[0.6rem] font-black italic text-white uppercase tracking-widest mt-0.5">Live Terminal</p>
                </div>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-8">
            <button onClick={() => setIsCommandOpen(true)} className="hidden md:flex items-center gap-6 px-8 py-3.5 glass-light rounded-[2rem] border border-white/5 hover:border-emerald-500/40 transition-all group scale-95 hover:scale-100 origin-right">
              <Command className="w-4 h-4 text-emerald-500" />
              <span className="text-[0.7rem] font-black uppercase tracking-[0.5em] text-slate-500">Access_Synapse</span>
              <div className="px-2 py-1 rounded-md bg-white/5 text-[0.6rem] text-slate-600 border border-white/5">⌘K</div>
            </button>
            <div className="w-14 h-14 rounded-2xl glass-light border border-emerald-500/20 p-1 hover:scale-105 transition-transform overflow-hidden shadow-2xl group cursor-pointer relative">
              <div className="absolute inset-0 bg-emerald-500/10 opacity-0 group-hover:opacity-100 transition-opacity" />
              <img src="/profile.jpg" className="w-full h-full object-cover rounded-xl" alt="U" />
            </div>
          </div>
        </header>

        <div
          ref={chatContainerRef}
          className="flex-1 overflow-y-auto custom-scrollbar p-12 space-y-16 scroll-smooth bg-transparent"
        >
          <div className="max-w-4xl mx-auto space-y-16 pb-64">
            {messages.length === 0 && (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="flex flex-col items-center text-center space-y-20 pt-32"
              >
                <div className="relative group">
                  <div className="absolute inset-x-[-100px] top-1/2 -translate-y-1/2 h-px bg-gradient-to-r from-transparent via-emerald-500/50 to-transparent blur-[1px] opacity-20 pointer-events-none" />
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ duration: 30, repeat: Infinity, ease: "linear" }}
                    className="w-40 h-40 rounded-[3rem] border border-emerald-500/10 p-8 glass shadow-[0_0_80px_rgba(16,185,129,0.15)] flex items-center justify-center relative"
                  >
                    <img src="/logo.png" className="w-full h-full object-contain mix-blend-screen" />
                    <div className="absolute inset-0 border border-emerald-500/20 rounded-[3rem] animate-pulse" />
                  </motion.div>
                </div>

                <div className="space-y-10">
                  <div className="space-y-4">
                    <p className="text-[0.75rem] font-black uppercase tracking-[1em] text-emerald-500">Initialization_Complete</p>
                    <h1 className="text-4xl md:text-6xl font-black italic tracking-tighter text-white uppercase leading-[0.85]">
                      Greetings. I am <br /><span className="text-emerald-500 text-gradient">Wakil Intelligence.</span>
                    </h1>
                  </div>
                  <p className="text-slate-500 text-xl font-medium max-w-2xl mx-auto leading-relaxed border-l-2 border-emerald-500/30 pl-8 uppercase tracking-widest text-left">
                    High-fidelity neural interface synchronized via Barada infrastructure.
                    Protocol operational for mission-critical objectives.
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 w-full max-w-4xl">
                  {[
                    { text: "Research the Barada AI Node", icon: Search, color: "text-blue-500" },
                    { text: "Initialize Visual Core Synthesis", icon: Sparkles, color: "text-emerald-500" },
                    { text: "Analyze Future Neural Roadmap", icon: Activity, color: "text-purple-500" },
                    { text: "Synchronize Logic Framework", icon: Code, color: "text-orange-500" }
                  ].map((action, i) => (
                    <motion.button
                      key={i}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.3 + (i * 0.1) }}
                      onClick={() => handleSuggestion(action.text)}
                      className="glass p-10 rounded-[3.5rem] border border-white/5 hover:border-emerald-500/40 hover:scale-[1.03] hover:shadow-[0_40px_100px_rgba(0,0,0,0.8)] transition-all text-left group flex items-start gap-8"
                    >
                      <div className={cn("w-16 h-16 rounded-3xl glass-light flex items-center justify-center flex-shrink-0 group-hover:bg-emerald-500 group-hover:text-black transition-all", action.color)}>
                        <action.icon className="w-8 h-8 group-hover:scale-125 transition-transform" />
                      </div>
                      <div className="space-y-3">
                        <p className="text-[0.65rem] font-black uppercase tracking-[0.4em] text-slate-500 group-hover:text-emerald-500/60 transition-colors">Protocol_Request</p>
                        <p className="text-xl font-black italic uppercase tracking-tighter text-slate-200">{action.text}</p>
                      </div>
                    </motion.button>
                  ))}
                </div>
              </motion.div>
            )}

            <AnimatePresence mode="popLayout">
              {messages.map((m, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 40, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  className={cn(
                    "flex gap-12 w-full group",
                    m.role === 'user' ? "flex-row-reverse" : "flex-row"
                  )}
                >
                  <div className={cn(
                    "w-9 h-9 flex items-center justify-center shrink-0 rounded-lg relative shadow-md overflow-hidden backdrop-blur-4xl border",
                    m.role === 'user' ? "bg-slate-900 border-emerald-500/20" : "glass border-emerald-500/20"
                  )}>
                    {m.role === 'user' ? <img src="/profile.jpg" className="w-full h-full object-cover" /> : <img src="/logo.png" className="w-6 h-6 object-contain mix-blend-screen drop-shadow-[0_0_8px_#10b981]" alt="A" />}
                    {m.role === 'assistant' && (
                      <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-emerald-500 rounded-full border-[2px] border-[#000205] animate-pulse shadow-glow" />
                    )}
                  </div>

                  <div className={cn(
                    "max-w-[80%] space-y-4",
                    m.role === 'user' ? "text-right" : "text-left"
                  )}>
                    <div className={cn(
                      "inline-block px-7 py-4 rounded-[1.5rem] relative overflow-hidden group/bubble backdrop-blur-4xl border border-white/5 shadow-md",
                      m.role === 'user'
                        ? 'bg-emerald-500 text-black font-semibold text-sm'
                        : 'glass text-slate-200'
                    )}>
                      {m.type === 'image' && m.status === 'loading' ? (
                        <div className="flex flex-col items-center gap-10 py-24 px-32 min-w-[300px]">
                          <div className="relative">
                            <Loader2 className="w-20 h-20 animate-spin text-emerald-400 opacity-20" />
                            <Sparkles className="absolute inset-0 m-auto w-8 h-8 text-emerald-500 animate-pulse" />
                          </div>
                          <p className="text-[0.75rem] font-black uppercase tracking-[0.8em] text-emerald-500 animate-pulse">Synthesis_Active</p>
                        </div>
                      ) : m.type === 'image' ? (
                        <ImageMessage src={m.content} />
                      ) : (
                        <div className={cn(
                          "prose prose-sm md:prose-lg font-medium leading-relaxed prose-invert prose-emerald max-w-full",
                          m.role === 'user' && "text-black text-right"
                        )}>
                          <ReactMarkdown remarkPlugins={[remarkGfm]}>{m.content}</ReactMarkdown>
                        </div>
                      )}

                      {/* Info Overlays */}
                      <div className={cn(
                        "absolute top-8 opacity-0 group-hover/bubble:opacity-100 transition-all flex gap-3",
                        m.role === 'user' ? "left-8" : "right-8"
                      )}>
                        <button onClick={() => handleCopy(m.content)} className={cn("p-3 rounded-2xl glass-light transition-all", m.role === 'user' ? "hover:bg-black/10 text-black/30 hover:text-black border-black/10" : "hover:bg-emerald-500 hover:text-black text-slate-500 border-white/10 hover:border-emerald-500")}>
                          <Copy className="w-5 h-5" />
                        </button>
                      </div>
                    </div>
                    {m.role === 'user' && (
                      <p className="text-[0.65rem] font-black uppercase tracking-[0.5em] text-emerald-500/50 mt-4 pr-6 flex items-center justify-end gap-3">
                        <Fingerprint className="w-4 h-4" /> SECURE_TRANSMISSION_NODE_OK
                      </p>
                    )}
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>

            {isLoading && !messages[messages.length - 1].type && (
              <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} className="flex gap-12">
                <div className="w-16 h-16 glass border border-emerald-500/20 flex items-center justify-center rounded-[1.5rem] animate-pulse backdrop-blur-4xl shadow-3xl">
                  <img src="/logo.png" className="w-10 h-10 object-contain mix-blend-screen" alt="T" />
                </div>
                <div className="glass px-12 py-8 rounded-[4rem] rounded-tl-xl flex items-center gap-6 shadow-3xl border border-white/5 backdrop-blur-4xl">
                  <span className="w-3 h-3 rounded-full bg-emerald-500 animate-bounce" style={{ animationDelay: '0ms' }}></span>
                  <span className="w-3 h-3 rounded-full bg-emerald-500 animate-bounce" style={{ animationDelay: '200ms' }}></span>
                  <span className="w-3 h-3 rounded-full bg-emerald-500 animate-bounce" style={{ animationDelay: '400ms' }}></span>
                </div>
              </motion.div>
            )}
            <div ref={scrollRef} className="h-20" />
          </div>
        </div>

        {/* Input Dock */}
        <div className="absolute bottom-16 left-0 right-0 px-12 pointer-events-none">
          <div className="max-w-5xl mx-auto w-full flex flex-col items-center gap-10">

            <AnimatePresence>
              {showScrollBtn && (
                <motion.button
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.8 }}
                  onClick={scrollToBottom}
                  className="p-6 glass border border-emerald-500/30 rounded-full text-emerald-400 hover:bg-emerald-500 hover:text-black transition-all pointer-events-auto shadow-4xl backdrop-blur-4xl active:scale-90"
                >
                  <ArrowDown className="w-8 h-8" />
                </motion.button>
              )}
            </AnimatePresence>

            <div className="w-full glass rounded-[2.5rem] p-3 border border-white/10 shadow-2xl pointer-events-auto backdrop-blur-4xl relative group/input">
              <div className="flex items-center gap-1.5 p-1 mb-2 bg-white/[0.03] rounded-full self-start w-fit border border-white/5 mx-4">
                {[
                  { id: 'chat', icon: MessageSquare, label: 'Chat' },
                  { id: 'image', icon: ImageIcon, label: 'Visual' },
                  { id: 'search', icon: SearchIcon, label: 'Research' },
                  { id: 'code', icon: Code, label: 'Core' },
                ].map((tool) => (
                  <button
                    key={tool.id}
                    onClick={() => setActiveTool(tool.id as any)}
                    className={cn(
                      "flex items-center gap-2 px-6 py-2 rounded-full text-[0.6rem] font-bold uppercase tracking-widest transition-all",
                      activeTool === tool.id ? "bg-emerald-500 text-black shadow-lg scale-105" : "text-slate-500 hover:text-slate-300"
                    )}
                  >
                    <tool.icon className="w-4 h-4" />
                    <span className="hidden md:inline">{tool.label}</span>
                  </button>
                ))}
              </div>

              <div className="flex items-end gap-6 px-10 py-6">
                <textarea
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      handleSend();
                    }
                  }}
                  placeholder={`Transmit to Wakil Intelligence Core (${activeTool})...`}
                  className="flex-1 bg-transparent border-none outline-none text-white font-medium placeholder-slate-700 resize-none py-5 max-h-64 min-h-[64px] custom-scrollbar text-xl tracking-tight leading-relaxed"
                />
                <div className="flex items-center gap-6">
                  <button className="p-5 text-slate-700 hover:text-emerald-500 transition-colors hidden sm:block">
                    <Wand2 className="w-8 h-8" />
                  </button>
                  <button
                    id="send-button"
                    onClick={handleSend}
                    disabled={isLoading || !input.trim()}
                    className="w-20 h-20 bg-emerald-500 rounded-[2.2rem] flex items-center justify-center text-black disabled:opacity-20 hover:scale-[1.05] active:scale-95 transition-all shadow-glow flex-shrink-0"
                  >
                    <Send className="w-9 h-9 ml-1.5" />
                  </button>
                </div>
              </div>
            </div>
            <p className="text-[0.7rem] font-black text-slate-700 uppercase tracking-[1em] opacity-40">System Architecture · 0x4f2A · V2.4</p>
          </div>
        </div>

        {/* --- TOASTS --- */}
        <div className="toast-container">
          {toasts.map(t => (
            <div key={t.id} className="toast glass border-emerald-500/40">
              <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-[0.75rem] font-black uppercase tracking-[0.2em]">{t.msg}</span>
            </div>
          ))}
        </div>

        {/* --- COMMAND PALETTE --- */}
        <AnimatePresence>
          {isCommandOpen && (
            <>
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setIsCommandOpen(false)} className="fixed inset-0 bg-black/95 backdrop-blur-3xl z-[99]" />
              <motion.div initial={{ y: 50, opacity: 0, scale: 0.95 }} animate={{ y: 0, opacity: 1, scale: 1 }} exit={{ y: 50, opacity: 0, scale: 0.95 }} className="command-palette z-[100] glass border-white/10 p-8 rounded-[4rem]">
                <div className="flex items-center gap-8 md:px-10 py-10 border-b border-white/5 mb-10">
                  <SearchIcon className="w-10 h-10 text-emerald-500" />
                  <input autoFocus placeholder="Initiate node search..." className="flex-1 bg-transparent border-none outline-none text-4xl text-white font-black italic tracking-tighter placeholder-slate-900 uppercase" />
                </div>
                <div className="space-y-4">
                  {[
                    { icon: Plus, label: "Establish Core Sync", action: () => { setMessages([]); setIsCommandOpen(false); } },
                    { icon: Settings, label: "Protocol Parameters", action: () => { setIsSettingsOpen(true); setIsCommandOpen(false); } },
                    { icon: LayoutDashboard, label: "Platform Overview", action: () => { window.location.href = "/"; } },
                  ].map((cmd, i) => (
                    <button key={i} onClick={cmd.action} className="w-full flex items-center gap-8 px-10 py-8 rounded-[2.5rem] hover:bg-emerald-500 hover:text-black transition-all group font-black text-sm uppercase tracking-[0.4em]">
                      <cmd.icon className="w-7 h-7" />
                      {cmd.label}
                    </button>
                  ))}
                </div>
              </motion.div>
            </>
          )}
        </AnimatePresence>

        {/* --- SETTINGS MODAL --- */}
        <AnimatePresence>
          {isSettingsOpen && (
            <div className="modal-overlay">
              <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.9 }} className="modal-content relative glass p-24 rounded-[5rem] border-white/10 max-w-4xl w-full backdrop-blur-4xl shadow-glow">
                <button onClick={() => setIsSettingsOpen(false)} className="absolute top-16 right-16 p-5 glass-light rounded-full transition-all border border-white/10 hover:bg-white/5">
                  <X className="w-8 h-8 text-slate-500" />
                </button>
                <div className="mb-20 space-y-4">
                  <h2 className="text-6xl font-black italic tracking-tighter text-white uppercase leading-none">PROTOCOL</h2>
                  <p className="text-[0.8rem] font-bold text-slate-600 uppercase tracking-[1em]">Neural Environment Interface</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-16">
                  <div className="space-y-10">
                    <label className="text-[0.85rem] font-black uppercase tracking-[0.4em] text-emerald-500 flex items-center gap-5">
                      <Monitor className="w-6 h-6" /> Aesthetics
                    </label>
                    <div className="grid grid-cols-2 gap-6">
                      {[
                        { id: 'dark', icon: Moon, label: 'Deep' },
                        { id: 'light', icon: Sun, label: 'Luminary' }
                      ].map((opt) => (
                        <button key={opt.id} className="p-8 glass-light rounded-[2.5rem] border border-white/5 flex flex-col items-center gap-5 hover:border-emerald-500/50 transition-all opacity-40">
                          <opt.icon className="w-8 h-8 text-white" />
                          <span className="text-[0.7rem] font-black uppercase tracking-widest">{opt.label}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-10">
                    <label className="text-[0.85rem] font-black uppercase tracking-[0.4em] text-emerald-500 flex items-center gap-5">
                      <Zap className="w-6 h-6" /> Pulse Sync
                    </label>
                    <div className="flex items-center justify-between p-10 glass-light rounded-[2.5rem] border border-white/5 h-full">
                      <span className="text-sm font-black text-slate-400 uppercase tracking-widest leading-relaxed">Neural Fluidity<br />Scaling</span>
                      <div className="w-20 h-10 bg-emerald-500 rounded-full flex items-center px-2 cursor-pointer shadow-glow">
                        <div className="w-7 h-7 bg-black rounded-full ml-auto shadow-2xl" />
                      </div>
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => setIsSettingsOpen(false)}
                  className="w-full mt-20 py-10 bg-emerald-500 text-black rounded-[2.5rem] font-black uppercase tracking-[1em] text-[0.8rem] hover:bg-white hover:scale-[1.02] transition-all shadow-glow"
                >
                  Commit Parameters
                </button>
              </motion.div>
            </div>
          )}
        </AnimatePresence>
      </main>

      <style jsx global>{`
        .shadow-glow {
           box-shadow: 0 0 50px rgba(16, 185, 129, 0.4);
        }
        .backdrop-blur-4xl {
           backdrop-filter: blur(60px);
           -webkit-backdrop-filter: blur(60px);
        }
        .text-gradient {
           background: linear-gradient(135deg, #fff 0%, #10b981 100%);
           -webkit-background-clip: text;
           -webkit-text-fill-color: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar {
          width: 8px;
          height: 8px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: rgba(16, 185, 129, 0.2);
          border-radius: 20px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: #10b981;
        }
      `}</style>
    </div>
  );
}
